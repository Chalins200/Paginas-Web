<html>
<body>
<?php
$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");
mysql_select_db("practica1caam",$c);
$sql="select * from Tabla1";
$r=mysql_query($sql,$c);
echo "<table border=1>";
echo "<tr><td>Persona</td><td>Color</td><td>Edad</td><td>Callenum</td><td>Colonia</td><td>Poblacion</td><td>Estado</td><td>Comentario</td></tr>";


      while ($arr=mysql_fetch_array($r))
      {
	echo"<tr>";      
	 echo "<td>{$arr['Nombre']}</td>";
	 echo "<td>{$arr['Color']}</td>";
	 echo "<td>{$arr['Edad']}</td>";
	 echo "<td>{$arr['Callenum']}</td>";
	 echo "<td>{$arr['Colonia']}</td>";
	 echo "<td>{$arr['Poblacion']}</td>";
	 echo "<td>{$arr['Estado']}</td>";
	 echo "<td>{$arr['Otro']}</td></tr>";
      }
      echo "</table><br><br>"
?>
<a href=alta.html><center><h1>Regresar</h1></a>
</body>
</html>