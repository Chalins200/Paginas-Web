<?php
$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");

mysql_select_db("practica1caam",$c);

$sql="update Tabla1 set Edad={$_POST['eda1']}, Color='{$_POST['col1']}', Callenum={$_POST['call1']}, Colonia='{$_POST['coln1']}', Poblacion={$_POST['pob1']}, Estado='{$_POST['est1']}', Otro='{$_POST['com1']}' where Nombre='{$_POST['nom1']}'";

mysql_query($sql,$c) or die ("Problema con la Modificacion...");

echo "Registro modificado";

echo"<a href=index.html><center><h1>REGRESAR</a>";

?>