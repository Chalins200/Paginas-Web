
<body>
<?php
$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");
mysql_select_db("practica1caam",$c);
$sql="select * from Tabla1 where Nombre='{$_POST['nom1']}'";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);     

	echo "<form action=modificacion3.php method=POST>";
	echo "Persona: <input type=text name=nom1 value={$arr['Nombre']}><br><br>";
	echo "Edad: <input type=text name=eda1 value={$arr['Edad']}><br><br>";
	echo "Color: <input type=text name=col1 value={$arr['Color']}><br><br>";	
	echo "Callenum: <input type=text name=call1 value={$arr['Callenum']}><br><br>";
	echo "Colonia: <input type=text name=coln1 value={$arr['Colonia']}><br><br>";
	echo "Poblacion: <input type=text name=pob1 value={$arr['Poblacion']}><br><br>";
	echo "Estado: <input type=text name=est1 value={$arr['Estado']}><br><br>";	
	echo "Comentario: <input type=text name=com1 value={$arr['Otro']}><br><br>";
	echo "<input type=submit value=Modificar>";
	echo "</form>";
?>
<a href=index.html><center><h1>Regresar</h1></a>
</body>
</html>