<html>
<body>
<?php
$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");
mysql_select_db("practica1caam",$c);
$sql="select * from Producto";
$r=mysql_query($sql,$c);
      while ($arr=mysql_fetch_array($r))
      {
	 echo "Codigo:".$arr['Codigo']."<br>";
	 echo "Descripcion:".$arr['Descripcion']."<br>";
	 echo "Cantidad:".$arr['Cantidad']."<br>";
	 echo "Precio:".$arr['Precio']."<br><br><br>";
      }
?>
<a href=venderpro.html><center><h1>Vender producto</h1></a>
<a href=compra.html><center><h1>Comprar producto</h1></a>
<a href=index.html><center><h1>Regresar</h1></a>

</body>
</html>