<html>
<body>
<?php
$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");
mysql_select_db("practica1caam",$c);

$sql="select * from Producto where Codigo='{$_POST['codg1']}'";

$r=mysql_query($sql,$c);
      while ($arr=mysql_fetch_array($r))
      {
	 echo "<form action=vender3.php method=POST>";
	 echo "Codigo: <input readonly=?readonly? name=codg1 value={$arr['Codigo']}><br>";
	 echo "Descripcion:".$arr['Descripcion']."<br>";
	 echo "Precio:".$arr['Precio']."<br>";
	 echo "Cantidad: <input readonly=?readonly? name=cant1 value={$arr['Cantidad']}><br>";
	 echo "<input type=submit value=Comprar>";
	 echo "</form>";
      }
?>
<a href=index.html><center><h1>Regresar</h1></a>
</body>
</html>