<?php

$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");

mysql_select_db("practica1caam",$c);

$r=mysql_query("insert into Producto(Codigo,Descripcion,Cantidad,Precio)
values('{$_POST['codg1']}','{$_POST['desc1']}','{$_POST['cant1']}','{$_POST[pre1]}')",$c);                                                
echo "Nuevo Producto Almacenado";
echo"<a href=consulta.php><center><h1>Consultar productos</h1></a>";
echo"<a href=index.html><center><h1>Regresar</h1></a>";
?>