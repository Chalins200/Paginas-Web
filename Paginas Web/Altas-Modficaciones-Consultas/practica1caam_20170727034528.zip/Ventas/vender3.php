<?php
$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");

mysql_select_db("practica1caam",$c);
$_POST['cant1'] -= 1;
$sql="update Producto set Cantidad={$_POST['cant1']} where Codigo={$_POST['codg1']}";

mysql_query($sql,$c) or die ("Problema con la Modificacion...");

echo "Producto comprado";

echo"<a href=index.html><center><h1>REGRESAR</a>";

?>