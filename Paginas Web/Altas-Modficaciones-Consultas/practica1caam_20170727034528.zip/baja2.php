<?php
$c=mysql_connect("mysql.webcindario.com","practica1caam","chalin123456");

mysql_select_db("practica1caam",$c);

$sql="delete from Tabla1 where Nombre='{$_POST['nom1']}'";                    

mysql_query($sql,$c);
echo"<a href=index.html><center><h1>REGRESAR</a>";

?>