<?php

$c=mysql_connect("mysql.webcindario.com","aplica","chalin123456");

mysql_select_db("practica1caam",$c);

$r=mysql_query("insert into Tabla1(nombre,edad,color,callenum,colonia,poblacion,estado,otro)
values('{$_POST['nom1']}','{$_POST['eda1']}','{$_POST['col1']}','{$_POST['call1']}','{$_POST['coln1']}','{$_POST['pob1']}','{$_POST['est1']}','{$_POST['com1']}')",$c);                                                
echo "Registro Almacenado Correctamente";

echo"<a href=alta.html><center><h1>Regresar</h1></a>";
?>