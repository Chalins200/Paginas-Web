<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$sql="insert into Usuarios values('','{$_POST['nombre']}','{$_POST['usuario']}','{$_POST['clave']}','{$_POST['privilegio']}')";
$r=mysql_query($sql,$c);

if($r){
header("Location:rEmpleado.php");
}else{
header("Location:error.html");
}
?>