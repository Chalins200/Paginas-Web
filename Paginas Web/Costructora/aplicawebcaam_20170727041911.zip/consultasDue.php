<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

if(strcmp($_SESSION['Privilegio'],"Due�o")== 0){
echo "
<!DOCTYPE html>
<html lang='es'>
	<head>
		<meta charset='utf-8'>
		<meta name='description' content='Ejemplo de HTML5 con CSS3'>
		<meta name='keywords' content='HTML5, CSS3, JavaScript'>
		<title>Constructora CAAM</title>
		<link rel='stylesheet' href='estilos.css'>
	</head>
	<body>
		<div id='agrupar'>
			<header id='cabecera'>
				<h1>CONSTRUCTORA CAAM</h1>
			</header>
			<nav id='menu'>
				<ul class='nav'>
					<li class='dropdown'> <a class='active' href='#'><span>OBRAS</span></a></li>
					<li class='dropdown'> <a class='active' href='cerrarsesion.php'><span>Cerrar Sesi&oacute;n</span></a></li>
				</ul>
			</nav>
		<section id='seccion'>";
			$sqlobra="select distinct nombre from Obras";
			$m=mysql_query($sqlobra,$c);
			$i=0;
			while($srr=mysql_fetch_array($m)){
			echo "<article>
					<header>
						<hgroup>
							<h1>{$srr['nombre']}</h1>";
							$sqlInge="select distinct encargado from Obras Where nombre='{$srr['nombre']}'";
							$mm=mysql_query($sqlInge,$c);
							echo "<h2>Ingeniero(s) encargado(s): ";
							while($sr=mysql_fetch_array($mm)){
					echo "		<br> {$sr['encargado']}";
					}
					echo "</h2></hgroup>
						<time datetime='2011-12-10' pubdate>Fecha de inicio: {$srr['fechaInicio']}</time>
					</header>
						{$srr['descripcion']}";
					$sqlFoto="select * from Obras Where nombre='{$srr['nombre']}'";
					$a=mysql_query($sqlFoto,$c);
					while($rr=mysql_fetch_array($a)){
					echo"<figure><img src='{$rr['foto']}' width=400px height:250px >
						<figcaption>
							{$rr['comentario']}
						</figcaption>
					</figure>";
					}
					$sqlCosto="select * from MaterialObra Where id_obra='{$srr['nombre']}'";
					$b=mysql_query($sqlCosto,$c);
					$cantidad = 0;
					echo "<h4>Lista del material utilizado:</h4>
					<ul style='background-color:#E0EEEE' >";
					while($r=mysql_fetch_array($b)){
						$cantidad += $r['cantidad'] * $r['precio'] ;
		
					echo "<li type='square'><span>{$r['nombreMaterial']} --- {$r['cantidad']} {$r['unidades']} --- $ {$r['precio']}</span><br></li>";
					}
					echo "</ul>
					<footer>
						<p>Costo actual: {$cantidad}</p>
						<p>Estado actual: {$srr['estado']}</p>
					</footer>
				</article>";
			}
	echo "</section>
			<footer id='pie'>
				&copy; Cesar Adrian Arteaga Mendoza ISC
			</footer>
		</div>
	</body>
</html>'";

}else{
header("Location:cerrarsesion.php");
}


?>