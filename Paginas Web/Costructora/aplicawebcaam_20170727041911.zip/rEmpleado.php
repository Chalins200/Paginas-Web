<?php
include('config.php');
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

if(strcmp($_SESSION['Privilegio'],"Secretaria")== 0){
echo "
<!DOCTYPE html>
<html lang='es'>
	<head>
		<meta charset='utf-8'>
		<meta name='description' content='Ejemplo de HTML5 con CSS3'>
		<meta name='keywords' content='HTML5, CSS3, JavaScript'>
		<title>Constructora CAAM</title>
		<link rel='stylesheet' href='estilos.css'>
	</head>
	<body>
		<div id='agrupar'>
			<header id='cabecera'>
				<h1>CONSTRUCTORA CAAM</h1>
			</header>
			<nav id='menu'>
				<ul class='nav'>
					<li class='dropdown'> <a class='active' href='rEmpleado.php'><span>REGISTRO DE EMPLEADOS</span></a></li>
					<li class='dropdown'> <a class='active' href='obras.php'><span>OBRAS</span></a></li>
					<li class='dropdown'> <a class='active' href='rRequisicion.php'><span>REQUISICI&Oacute;N</span></a></li>
					<li class='dropdown'> <a class='active' href='cerrarsesion.php'><span>Cerrar Sesi&oacute;n</span></a></li>
				</ul>
			</nav>
			<section id=seccion>
				<article>
					<header>
						<hgroup>
							<h1>Registro de empleados</h1>
							<h2>Ingresa la informaci&oacute;n completa del empleado</h2>
						</hgroup>
						
					</header>
						<form action='rEmpleados2.php' method=POST enctype='multipart/form-data'>
						<table>
							<tr>
								<td>Nombre:</td>
								<td><input type=text name=nombre><br></td>
							</tr>
							<tr>
								<td>Puesto:</td>
								<td><select name='privilegio'>
								<option name='1' value='Due�o'>Due&ntilde;o</option>
								<option name='2' value='Secretaria'>Secretaria</option>
								<option name='3' value='Ingeniero'>Ingeniero</option>
								</select></td>
							</tr>
							<tr>
								<td>Usuario:</td>
								<td><input type=text name=usuario><br></td>
							</tr>
							<tr>
								<td>Clave:</td>
								<td><input type=text name=clave><br></td>
							</tr>
							<th colspan=2 align=center><input  type=submit name=Inicio value=Registrar class=submit></th>
						</table>
						</form>
					
				</article>
				
			</section>
			<aside id=columna>
			</aside>
			<footer id=pie>
				&copy; Cesar Adrian Arteaga Mendoza ISC
			</footer>
		</div>
	</body>
</html>";

}else{
header("Location:cerrarsesion.php");
}


?>