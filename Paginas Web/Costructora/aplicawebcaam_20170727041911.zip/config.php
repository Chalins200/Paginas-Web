<?php
$datos = array('0' => 'mysql.webcindario.com',
              '1' => 'aplicawebcaam',
              '2' => '123456');
?>