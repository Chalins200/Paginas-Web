<?php
include("config.php");
session_start();

$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$foto=$_FILES['foto']['name'];
$ruta=$_FILES['foto']['tmp_name'];
$destino="images/".$foto;
copy($ruta,$destino);

$sql="insert Into Obras values('{$_POST['id']}','{$_POST['nomObra']}','{$_POST['encargado']}','{$_POST['porcentaje']}','{$destino}','En construccion','','{$_POST['comentario']}','{$_POST['Fecha']}')";
$r=mysql_query($sql,$c); 

if($r){
header("Location:Ingobras.php");
}else{
header("Location:error.html");
echo $sql;
}
?>