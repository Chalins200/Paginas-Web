<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);


$sql="insert into MaterialObra values('','{$_POST['material']}','{$_POST['cantidad']}','{$_POST['unidades']}','{$_POST['precio']}','{$_POST['obra']}','{$_POST['estadoCompra']}','Pendiente')";
$r=mysql_query($sql,$c); 

if($r){
header("Location:rRequisicion.php");
}else{
header("Location:error.php");
}
?>