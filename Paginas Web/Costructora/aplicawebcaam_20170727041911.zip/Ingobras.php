<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

if(strcmp($_SESSION['Privilegio'],"Ingeniero")== 0){
echo "
<!DOCTYPE html>
<html lang='es'>
	<head>
		<meta charset='utf-8'>
		<meta name=description content='Ejemplo de HTML5 con CSS3'>
		<meta name=keywords content='HTML5, CSS3, JavaScript'>
		<title>Constructora CAAM</title>
		<link rel=stylesheet href=estilos.css>
	</head>
	<body>
		<div id=agrupar>
			<header id=cabecera>
				<h1>CONSTRUCTORA CAAM</h1>
			</header>
			<nav id=menu>
				<ul class=nav>
					<li class='dropdown'> <a class='active' href='#'><span>OBRAS</span></a></li>
					<li class='dropdown'> <a class='active' href='rmaterial.php'><span>REGISTRAR MATERIAL</span></a></li>
					<li class='dropdown' align=right> <a class='active' href='cerrarsesion.php'><span>Cerrar Sesion</span></a></li>
				</ul>
			</nav>
			<section id=seccion>
				<article>
					<header>
						<hgroup>
							<h1>Registro de avance</h1>
							<h2>Detalles de obras</h2>
						</hgroup>
						<time datetime='2011-12-10' pubdate>Selecciona la informaci&oacute;n correspondiente</time>
					</header>
						
						<table>
						
							<tr>
								<td>Identificador de obra (ID):</td>
								<td><form action=Ingobras.php method=POST enctype='multipart/form-data'>
								<select name='id_obra'>";
								$sql="Select * from Obras Where encargado='Cesar'";
								$m=mysql_query($sql,$c);
								$i=0;
								while($srr=mysql_fetch_array($m)){
								$id=$srr['id_obra'];
								echo "		<option name='$i' value='{$srr['id_obra']}'>{$srr['id_obra']}</option>";
										}
								echo"	</select>
								<input  type=submit value='Buscar obra' class=submit></form><br>
								
								</td>
							</tr>
							<tr>
								<td><form action=Ingobras2.php method=POST enctype='multipart/form-data'>
								<input type=hidden name=id value={$id}>
								Nombre de la obra:</td>
								<td><select name='nomObra'>";
								$sq="Select distinct encargado, nombre from Obras Where id_obra='{$_POST['id_obra']}'";
								$mm=mysql_query($sq,$c);
								$i=0;
								while($sr=mysql_fetch_array($mm)){
								echo "		<option name='$i' value='{$sr['nombre']}'>{$sr['nombre']}</option>";
										
								echo"	</select><br></td>
							</tr>
							<tr>
								<td>Fecha:</td>
								<td><input type=text name='Fecha' value='AAAA-MM-DD'><br></td>
							</tr>
							<tr>
								<td>Encargado de la obra:</td>
								<td><select name='encargado'>
								<option name='$i' value={$sr['encargado']}>{$sr['encargado']}</option>
								</select><br>
								</td>
							</tr>
							<tr>
								<td>Porcentaje :</td>
								<td><input type=text name='porcentaje' value={$sr['porcentaje']}>"; } echo "<br></td>
							</tr>
							<tr>
								<td>Foto de avance:</td>
								<td><input type='file' name='foto' value='' id=foto><br></td>
							</tr>
							<tr>
								<td>Comentario:</td>
								<td><input type=text name='comentario'><br></td>
							</tr>
							<th colspan=2 align=center><input  type=submit value='Registrar obra' class=submit></th>
						</table>
						</form>
					
				</article></section>
			<aside id='columna'>
				<h2>Avances de las obras</h2>
				<ul class=projects>";
			$sql="select * from Obras";
			$m=mysql_query($sql,$c);
			$i=0;
			while($srr=mysql_fetch_array($m)){
			echo "<li><img src='{$srr['foto']}' width=250px height:150px /><br><br><br><br><br><h4>".$srr['nombre']."</h4>
			Encargado: ".$srr['encargado']."<br>".$srr['estado']."<br>".$srr['porcentaje']."</li>";
			}
			echo "</ul></aside>
			<footer id='pie'>
				&copy; Cesar Adrian Arteaga Mendoza ISC
			</footer>
		</div>
	</body>
</html>";

}else{
header("Location:cerrarsesion.php");
}


?>