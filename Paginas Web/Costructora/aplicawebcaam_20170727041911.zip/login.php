<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);
$sql="select * from Usuarios where usuario='".$_POST['usuario']."' and clave='".$_POST['clave']."' FOR UPDATE";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);
echo $arr['nombre'];

if(strcmp($arr['privilegio'],"Secretaria")== 0){
header("Location:rEmpleado.php");
}else if(strcmp($arr['privilegio'],"Ingeniero")== 0){
header("Location:Ingobras.php");
}else if(strcmp($arr['privilegio'],"Due�o")== 0){
header("Location:consultasDue.php");
}else{
header("Location:index.html");
}
$_SESSION['Usuario'] = $arr['usuario'];
$_SESSION['Clave'] = $arr['clave'];
$_SESSION['Privilegio'] = $arr['privilegio'];

?>