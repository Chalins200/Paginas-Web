<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$sq="Select * from MaterialObra Where id_obra='{$_POST['idobra']}' and nombreMaterial='{$_POST['nombreM']}'";
$rr=mysql_query($sq,$c); 

while($sr=mysql_fetch_array($rr)){

if(strcmp($_POST['cantidad'],$sr['cantidad'])== 0){
$sql="UPDATE MaterialObra set cantidadRecibida='{$_POST['cantidad']}', estadoEntrega='Recibido' Where id_obra='{$_POST['idobra']}' and nombreMaterial='{$_POST['nombreM']}'";
$r=mysql_query($sql,$c); 
}else{
$sql="UPDATE MaterialObra set cantidadRecibida='{$_POST['cantidad']}' Where id_obra='{$_POST['idobra']}' and nombreMaterial='{$_POST['nombreM']}'";
$r=mysql_query($sql,$c); 
}

}

if($r){
header("Location:rmaterial.php");
}else{
header("Location:error.php");
}
?>