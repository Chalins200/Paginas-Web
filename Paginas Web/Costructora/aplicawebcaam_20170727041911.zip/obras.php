<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

if(strcmp($_SESSION['Privilegio'],"Secretaria")== 0){
echo "
<!DOCTYPE html>
<html lang='es'>
	<head>
		<meta charset='utf-8'>
		<meta name=description content='Ejemplo de HTML5 con CSS3'>
		<meta name=keywords content='HTML5, CSS3, JavaScript'>
		<title>Constructora CAAM</title>
		<link rel=stylesheet href=estilos.css>
		
		<script type='text/javascript'>
<!--
function actualizaReloj(){ 
	/* COMIENZA EL SCRIPT DE LA FECHA */ 
var Mes = new Array('01','02','03','04','05','06','07','08','09','10','11','12'); 
var Hoy = new Date(); 
var Anio = Hoy.getFullYear(); 
var Fecha = Hoy.getDate() + ' de ' + Mes[Hoy.getMonth()] + ' de ' + Anio; 
	/* TERMINA EL SCRIPT DE LA FECHA */ 

	/* CREAMOS 4 VARIABLES PARA DARLE FORMATO A NUESTRO SCRIPT */ 
var Script, Total 

	/* EN INICIO LE INDICAMOS UN COLOR DE FUENTE Y UN TAMA�O */ 

	/* EN RELOJ LE INDICAMOS LA HORA, LOS MINUTOS Y LOS SEGUNDOS */ 
Script = Fecha 

	/* EN TOTAL FINALIZAMOS EL RELOJ UNIENDO LAS VARIABLES */ 
Total = Script

	/* CAPTURAMOS UNA CELDA PARA MOSTRAR EL RELOJ */ 
document.getElementById('Fecha').innerHTML = Total 

	/* INDICAMOS QUE NOS REFRESQUE EL RELOJ CADA 1 SEGUNDO */ 
setTimeout('actualizaReloj()',1000)  
} 
-->
</script>
		
		
		
	</head>
	<body onload='actualizaReloj()'>
		<div id=agrupar>
			<header id=cabecera>
				<h1>CONSTRUCTORA CAAM</h1>
			</header>
			<nav id=menu>
				<ul class=nav>
					<li class='dropdown'> <a class='active' href='rEmpleado.php'><span>REGISTRO DE EMPLEADOS</span></a></li>
					<li class='dropdown'> <a class='active' href='obras.php'><span>OBRAS</span></a></li>
					<li class='dropdown'> <a class='active' href='rRequisicion.php'><span>REQUISICI&Oacute;N</span></a></li>
					<li class='dropdown'> <a class='active' href='cerrarsesion.php'><span>Cerrar Sesi&oacute;n</span></a></li>
				</ul>
			</nav>
			<section id=seccion>
				<article>
					<header>
						<hgroup>
							<h1>Registro y consulta de obras</h1>
							<h2>Ingresa la informaci&oacute;n de la obra</h2>
						</hgroup>
						</header>
						<form action=rObras2.php method=POST enctype='multipart/form-data'>
						<table>
							<tr>
								<td>Fecha:</td>
								<td><input type=text name='Fecha' value='AAAA-MM-DD'><br></td>
							</tr>
							<tr>
								<td>Identificador de obra (ID):</td>
								<td><input type=text name='id_obra'><br></td>
							</tr>
							<tr>
								<td>Nombre de la obra:</td>
								<td><input type=text name='nomObra'><br></td>
							</tr>
							<tr>
								<td>Encargado de la obra:</td>
								<td><select name='encargado'>";
								$sql="select * from Usuarios Where privilegio='Ingeniero'";
								$m=mysql_query($sql,$c);
								$i=0;
								while($srr=mysql_fetch_array($m)){
								echo "		<option name='$i' value={$srr['nombre']}>{$srr['nombre']}</option>";
										}
								echo"	</select><br>
								</td>
							</tr>
							<tr>
								<td>Porcentaje:</td>
								<td><input type=text name='porcentaje'><br></td>
							</tr>
							<tr>
								<td>Descripcion breve:</td>
								<td><textarea name='descripcion' rows='4' cols='30'></textarea><br></td>
							</tr>
							<tr>
								<td>Foto:</td>
								<td><input type='file' name='foto' value='' id=foto><br></td>
							</tr>
							<th colspan=2 align=center><input  type=submit name=Inicio value='Registrar obra' class=submit></th>
						</table>
						</form>
					
				</article></section>
			<aside id='columna'>
				<h2>Avance y detalles de obras</h2>
				<ul class=projects>";
			$sql="select * from Obras";
			$m=mysql_query($sql,$c);
			$i=0;
			while($srr=mysql_fetch_array($m)){
			echo "<li><img src='{$srr['foto']}' width=250px height:150px /><br><br><br><br><br><h4>".$srr['nombre']."</h4>
			Encargado: ".$srr['encargado']."<br>".$srr['estado']."</li>";
			}
			echo "</ul></aside>
			<footer id='pie'>
				&copy; Cesar Adrian Arteaga Mendoza ISC
			</footer>
		</div>
	</body>
</html>";

}else{
header("Location:cerrarsesion.php");
}


?>