<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

if(strcmp($_SESSION['Privilegio'],"Ingeniero")== 0){
echo "
<!DOCTYPE html>
<html lang='es'>
	<head>
		<meta charset='utf-8'>
		<meta name=description content='Ejemplo de HTML5 con CSS3'>
		<meta name=keywords content='HTML5, CSS3, JavaScript'>
		<title>Constructora CAAM</title>
		<link rel=stylesheet href=estilos.css>
	</head>
	<body>
		<div id=agrupar>
			<header id=cabecera>
				<h1>CONSTRUCTORA CAAM</h1>
			</header>
			<nav id=menu>
				<ul class=nav>
					<li class='dropdown'> <a class='active' href='Ingobras.php'><span>OBRAS</span></a></li>
					<li class='dropdown'> <a class='active' href='rmaterial.php'><span>REGISTRAR MATERIAL</span></a></li>
					<li class='dropdown' align=right> <a class='active' href='cerrarsesion.php'><span>Cerrar Sesion</span></a></li>
				</ul>
			</nav>
			<section id=seccion>
				<article>
					<header>
						<hgroup>
							<h1>Registro de Material</h1>
						</hgroup>
						<time datetime='2011-12-10' pubdate>Selecciona la informaci&oacute;n correspondiente</time>
					</header>
						
						<table>
							<tr>
								<td>Identificador de obra (ID):</td>
								<td><form action=rmaterial.php method=POST enctype='multipart/form-data'>
								<select name='id_obra'>";
								$sql="Select * from Obras Where encargado='Cesar'";
								$m=mysql_query($sql,$c);
								$i=0;
								while($srr=mysql_fetch_array($m)){
								$id=$srr['nombre'];
								echo "		<option name='$i' value='{$srr['nombre']}'>{$srr['nombre']}</option>";
										}
								echo"	</select>
								<input  type=submit value='Buscar obra' class=submit></form><br>
								
								</td>
							</tr>
							<tr>
								<td><form action=rmaterial2.php method=POST enctype='multipart/form-data'>
								
								Material de la obra:</td>
								<td><select name='material'>";
								$sq="Select * from MaterialObra Where id_obra='{$_POST['id_obra']}' and estadoEntrega='Pendiente'";
								$mm=mysql_query($sq,$c);
								$i=0;
								$idobra = $_POST['id_obra'];
								
								while($sr=mysql_fetch_array($mm)){
								$nombreM = $sr['nombreMaterial'];
								echo "<option name='$i' value='{$sr['nombreMaterial']}'>{$sr['nombreMaterial']}  {$sr['cantidad']} {$sr['unidades']}</option>";
								}		
								echo"	</select>
								<input type=hidden name=idobra value='{$idobra}'>
								<input type=hidden name=nombreM value='{$nombreM}'></td>
							</tr>
							<tr>
							<td>Cantidad recibida:</td>
							<td><input  type=text name='cantidad'></td>
							</tr>
							<th colspan=2><input  type=submit value='Registrar Material' class=submit></th>
						</table>
						</form>
					
				</article></section>
			<aside id='columna'>
				<h2>Obras</h2>
				<ul class=projects>";
			$sql="select * from Obras";
			$m=mysql_query($sql,$c);
			$i=0;
			while($srr=mysql_fetch_array($m)){
			echo "<li><img src='{$srr['foto']}' width=250px height:150px /><br><br><br><br><br><h4>".$srr['nombre']."</h4>
			Encargado: ".$srr['encargado']."<br>".$srr['estado']."</li>";
			}
			echo "</ul></aside>
			<footer id='pie'>
				&copy; Cesar Adrian Arteaga Mendoza ISC
			</footer>
		</div>
	</body>
</html>";

}else{
header("Location:cerrarsesion.php");
}


?>