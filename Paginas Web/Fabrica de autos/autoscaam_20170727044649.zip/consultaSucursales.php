<html>
<MARQUEE BGCOLOR="#4682B4">..:: CONSULTA SUCURSAL ::..</h1></MARQUEE><p>

<body BGCOLOR="#4682B4">
<?php
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

$sql="select * from Sucursales";
$r=mysql_query($sql,$c);

echo "<table border=1>";
echo "<tr><td>Id_Sucursal</td><td>Nombre</td><td>Ubicacion</td>";

      while ($arr=mysql_fetch_array($r))
      {
      	echo "<tr>";
      	echo "<td>{$arr['Id_Sucursal']}</td>";
      	echo "<td>{$arr['Nombre']}</td>";
      	echo "<td>{$arr['Ubicacion']}</td>";
      	
      
      }
      echo "</table><br><br>";
?>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>