<html>
<body>
<?php
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

$sql="update Autos set Ubicacion='{$_POST['ubicacion']}' where Id_Auto='{$_POST['idauto']}' ";

mysql_query($sql,$c) or die ("Problema con la Modificacion...");



	if($_COOKIE['Id_Sucursal'] == $_POST['idsucursal']){
	
$sql2="update Autos set Estado='En_Destino' where Id_Auto='{$_POST['idauto']}' ";
mysql_query($sql2,$c);
echo "<h1>Llego al destino<br><br></h1>";
?>

<center><a href="entregarAuto.php" title="Entregar al cliente">Entregar al Cliente</a><br><br>

<?php
	}else {echo "<h1>Aun sigue en proceso<br></h1>";}


?>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>

</body>
</html>