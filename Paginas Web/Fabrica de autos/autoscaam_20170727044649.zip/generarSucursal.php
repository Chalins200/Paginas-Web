<?php
$Sucursal = 'MiNombre';

$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

// sql to create table
$query = mysql_query("CREATE TABLE ".$_POST['nombre']." (
Id_Sucursal VARCHAR(30) NOT NULL PRIMARY KEY, 
Nombre VARCHAR(30) NOT NULL,
Ubicacion VARCHAR(30) NOT NULL,
Tipo VARCHAR(30) NOT NULL)");

setcookie("Nueva_Sucursal", "{$_POST['idsucursal']}", time()+3600);

$s=mysql_query("insert into ".$_POST['nombre']."(Id_Sucursal,Nombre,Ubicacion,Tipo)
values('{$_POST['idsucursal']}','{$_POST['nombre']}','{$_POST['ubicacion']}','{$_POST['tipo']}')",$c);

                                             
$r=mysql_query("insert into Sucursales (Id_Sucursal,Nombre,Ubicacion,Tipo)
values('{$_POST['idsucursal']}','{$_POST['nombre']}','{$_POST['ubicacion']}','{$_POST['tipo']}')",$c);                                                
echo "Realizado";
echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=registrarPrimerEmpleado.php'><body>Espera, te vamos a redireccionar </body></html>";
?>

<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>