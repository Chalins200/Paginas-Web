<?php
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);


$sql="update Clientes set Nombre='{$_POST['nom']}',Contrase�a='{$_POST['con']}' where Id_Cliente='{$_POST['idC']}'";

mysql_query($sql,$c) or die ("Problema con la Modificacion...");

echo "Registro modificado";

?>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>