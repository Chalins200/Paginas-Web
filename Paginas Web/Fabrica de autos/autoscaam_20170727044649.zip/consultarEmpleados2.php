<html>
<MARQUEE BGCOLOR="#4682B4">..::CONSULTAR EMPLEADOS::..</h1></MARQUEE><p>
 
<body BGCOLOR="#4682B4">


<?php
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

$sql="select * from Empleados where Id_Empleado='{$_POST['IdEmpleado']}' and Id_Sucursal={$_COOKIE['Id_Sucursal']}";
$r=mysql_query($sql,$c);

echo "<table border=1>";
echo "<tr><td>Id_Empleado</td><td>Nombre</td><td>Id_Empleado</td><td>Tipo</td><td>Contrase�a</td></tr>";


      while ($arr=mysql_fetch_array($r))
      {
	echo"<tr>";      
	 echo "<td>{$arr['Id_Empleado']}</td>";
	 echo "<td>{$arr['Nombre']}</td>";
	 echo "<td>{$arr['Id_Sucursal']}</td>";
	 echo "<td>{$arr['Tipo']}</td>";
	 echo "<td>{$arr['Contrase�a']}</td></tr>";
      }
      echo "</table><br><br>"
?>


<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>