<html>

<MARQUEE BGCOLOR="#4682B4">..:: Registrar cliente ::..</h1></MARQUEE>
<MARQUEE ALIGN=CENTER HEIGHT=60 DIRECTION=up> DINACORP
</MARQUEE> 
<head>
	<title>Registrar Cliente</title>
	
</head>
<body BGCOLOR="#4682B4">

<?php	
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);
	
	$sql2=mysql_query("insert into Clientes(Id_Cliente,Nombre,Id_Sucursal,Id_Auto,Contrase�a)
	values('{$_POST['idcliente']}','{$_POST['nombre']}','{$_COOKIE['Id_Sucursal']}','{$_COOKIE['Auto']}','{$_POST['contrase�a']}')",$c);
	
	echo "Cliente registrado correctamente <br>	";
	
	//echo "insert into Clientes(Id_Cliente,Nombre,Id_Sucursal,Id_Auto,Contrase�a)<br>
	//values('{$_POST['idcliente']}','{$_POST['nombre']}','{$_COOKIE['Id_Sucursal']}','{$_COOKIE['Auto']}','{$_POST['contrase�a']}')";
	
	
?>

<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>