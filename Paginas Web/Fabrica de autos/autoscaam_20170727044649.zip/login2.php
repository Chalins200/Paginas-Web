<?php
setcookie("Servidor", "mysql.webcindario.com", time()+3600);
setcookie("Usuario", "autoscaam", time()+3600);
setcookie("Contrase�a", "autoscaam", time()+3600);
// Configura los datos de tu cuenta
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

if ($_POST['user1'] ) {
//Comprobacion del envio del nombre de usuario y password
$username=$_POST['user1'];
$password=$_POST['pass1'];

if ($password==NULL) {
	
echo "Debes Escribir el Password";

}else{
 
$query = mysql_query("SELECT * FROM Empleados WHERE Id_Empleado = '$username'" ) or die(mysql_error());
$data = mysql_fetch_array($query);
$Id_Sucursal = $data['Id_Sucursal'];
$TipoEm = $data['Tipo'];
setcookie("Id_Sucursal", "$Id_Sucursal", time()+3600);

	if($data['Contrase�a'] != $password) {
	
		$query = mysql_query("SELECT * FROM Clientes WHERE Id_Cliente = '$username'" ) or die(mysql_error());
		$data = mysql_fetch_array($query);
		if($data['Contrase�a'] != $password) {
		echo "Usuario o Contrase�a  Incorrecto";
		}else{
		echo "Cliente ____";
		echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=consultaVehiculo.php'><body>Espera, te vamos a redireccionar </body></html>";
		}	
	
		
	}else{
	
			if($TipoEm == "Gerente") {
			
				$query = mysql_query("SELECT * FROM Sucursales WHERE Id_Sucursal = '$Id_Sucursal'" ) or die(mysql_error());
				$dataa = mysql_fetch_array($query);
				$TipoSuc = $dataa['Tipo'];
				$Ubicacion = $dataa['Ubicacion'];
				setcookie("SucursalActual", "$Ubicacion", time()+3600);
				
				if($TipoSuc == "Fabrica"){
				echo "Fabrica Gerente ___ ";
				echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=indexFabricaGerente.html'><body>Espera, te vamos a redireccionar </body></html>";
				
				}else{

				echo "Sucursal Gerente  ____";
				
				echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=indexSucursalGerente.html'><body>Espera, te vamos a redireccionar </body></html>";
				}


			}else if($TipoEm == "Secretaria") {
			
				$query = mysql_query("SELECT * FROM Sucursales WHERE Id_Sucursal = '$Id_Sucursal'" ) or die(mysql_error());
				$dataa = mysql_fetch_array($query);
				$TipoSuc = $dataa['Tipo'];
				$Ubicacion = $dataa['Ubicacion'];
				setcookie("SucursalActual", "$Ubicacion", time()+3600);
				if($TipoSuc == "Fabrica"){
				
					echo "Fabrica Secretaria  ____";
					echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=indexFabricaSecretaria.html'><body>Espera, te vamos a redireccionar </body></html>";
				
				}else {
				
					echo "Sucursal Secretaria  ____";
					echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=indexSucursalSecretaria.html'><body>Espera, te vamos a redireccionar </body></html>";
				}

			}

	}
   }
}

?>