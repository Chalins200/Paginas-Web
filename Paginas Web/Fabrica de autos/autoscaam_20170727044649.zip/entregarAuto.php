<html>
<body>

<?php

$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

//Eliminar Cliente
$sql0="select * from Clientes where Id_Auto='{$_COOKIE['Id_Auto']}'";
$r=mysql_query($sql0,$c);
$arr=mysql_fetch_array($r);  

mysql_query("delete from Clientes where Id_Cliente='{$arr['Id_Cliente']}'",$c);

//Eliminar Auto
$sql="delete from Autos where Id_Auto='{$_COOKIE['Id_Auto']}' ";
mysql_query($sql,$c);

echo "<h1>Se entrego al cliente correctamente</h1>";
	
?>


<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>



</body>
</html>