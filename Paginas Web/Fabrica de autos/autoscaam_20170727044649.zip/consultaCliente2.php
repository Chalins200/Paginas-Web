<html>
<body BGCOLOR="#4682B4">
<head>
<MARQUEE BGCOLOR="#4682B4F">..:: Consulta Clientes ::..</h1></MARQUEE>	 
	
</head>

<?php
echo "<h1 align=center>Fabricadora de Vehiculos DinaCorp</h1>";
echo "<hr width=500><hr width=400><hr width=300><hr width=200><hr width=100>";
echo "<h1>";
echo "	Identificador de auto: <input type=text name=idAuto><br>";
echo "Cliente: <br>";
echo "	Sucursal: <br>
	Ubicacion actual:<br>
	Estado: <br></h1>";
	
	?>



<br>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>