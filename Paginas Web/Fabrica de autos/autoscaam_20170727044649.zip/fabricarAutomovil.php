<html>
<body BGCOLOR="#4682B4" Text=#FFF8DC>
<MARQUEE BGCOLOR="#4682B4">..:: Registrar Pedido ::..</h1></MARQUEE>
 
<head>
	<title>Pedido</title>
	
</head>
<form action=fabricarAutomovil2.php method=POST>
<?php
echo "<h1>";

echo "<TABLE border=0 width=400 align=left> <TR> <TD width=100 align=left> Serial de Vehiculo: </TD> <TD align=left> <input type=text name=SV1></TD></TR>";
	
	echo "<TR> <TD  align=left> Tipo de Vehiculo: </TD> <TD  align=left>  <select name=Tipo><option>Automovil</option><option>Camioneta</option><option>Motocicleta</option><option>Autobus</option><option>Cami�n</option></select></TD></TR>";
	echo "<TR> <TD  align=left> Color: </TD> <TD  align=left> <input type=text name=Color></TD></TR>";
	echo "<TR> <TD  align=left> Numero de Puertas: </TD> <TD  align=left> <input type=text name=NPuertas></TD></TR>";
	echo "<TR> <TD  align=left> Transmisi�n: </TD> <TD  align=left>  <select name=Transmision><option>Estandar</option><option>Automatica</option></select></TD></TR>";
	echo "<TR> <TD  align=left> Combustible: </TD> <TD  align=left>  <select name=Combustible><option>Gasolina</option><option>Diesel</option><option>Gas LP</option></select></TD></TR>";
	
		
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

	$sql2="select * from Sucursales";
	$r2=mysql_query($sql2,$c);
	
	echo "<TR> <TD width=50 align=left> Id_Sucursal: </TD> <TD width=50 align=left> {$_COOKIE['Id_Sucursal']} </TD></TR> ";	
	
	echo "<TR> <TD width=50 align=left> Estado: </TD> <TD width=50 align=left> En Proceso";
	
	echo "<TR> <TD width=50 align=left> Comentario: </TD> <TD width=50 align=left>  <input type=text name=Comentario></TD></TR>";
	
	
	echo "<TR> <TD width=50 align=left> </TD> <TD width=50 align=right> <input type=submit value=AGREGAR></TD></TR></TABLE>";
	echo "</h1> <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
	
	
?>

</form>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a></center>
</body>
</html>