<?php
echo "<h1 align=center>INTRODUCCION</h1> <br>
<br>
<br>
Un software es un conjunto de programas y rutinas que permiten a la computadora realizar determinadas tareas y que a su vez �sta facilite el trabajo y las tareas realizadas de una forma m�s r�pida y eficiente. En la empresa apoyo econ�mico se busca sustituir el sistema con el que cuentan actualmente por un sistema que cumpla con todas las necesidades para un desarrollo eficaz econ�mico, operativo y t�cnico.<br>
<br><br>

En el presente documento se mencionan algunas propuestas de sistemas administrativos dedicados especialmente a peque�as y medianas empresas con giro de ventas, cumpliendo con los procesos b�sicos que se realizan en este tipo de empresas. <br>
Se realiza un an�lisis con ayuda de entrevistas y un cuestionario para saber la situaci�n actual de la empresa. Con ello obtenemos datos generales y espec�ficos como: el paso a paso de cada uno de los procesos administrativos que se realizan en cada �rea, las problem�ticas que se presentan y el estado de las maquinas donde se est� utilizando el sistema actual. <br>
Con lo mencionado se pretende dar a conocer algunas propuestas que tienen como objetivo satisfacer las necesidades de la empresa. 
<br><br><br><br>




<h1 align=center>ANTECEDENTES Y TRABAJOS PREVIOS<br></h1>
<br>
<br>Sr. Arturo Castillo director general de la empresa dinacorp ubicada en Tulancingo Hidalgo calle 1ra de mayo no. 107, Colonia Centro la cual se encuentra laborando desde el a�o 2005 con un giro financiero.
<br>La empresa dinacorp cuenta con un software propio para los trabajos administrativos de su empresa el cual se encarga de realizar tareas administrativas de las �reas en las cuales se encuentra dividida la empresa.
<br>
<br><h2 align=center>SITUACION ACTUAL</h2>
<br>La empresa dinacorp necesita un software para llevar el control de sus ventas y producto donde el cual desde una concesionaria llega el cliente y hace un pedido donde se llena un formato en el cual se registra las caracter�sticas del auto como tipo, color, numero de puertas, tipo de trasmisi�n, tipo de combustible y un comentario para los casos necesarios, al �ltimo de le asigna un id autom�tico donde se hace la cuenta desde un contador simple. Se registra el cliente �l se le pide  su nombre, el destino donde quiere el auto y al final se le asigna un id al cliente y  id del auto se obtiene del que se cre�. Una vez visto el pedido la f�brica lo busca en inventario y si no est� en inventario se empieza a fabricar r�pidamente, una vez fabricado el auto la f�brica manda el carro a la sucursal m�s cercana donde esa sucursal registra el carro para verificar que si ya llego a su destino pero si no ha llegado a su destino el auto es reenviado y as� sucesivamente hasta llegar a la sucursal de destino una vez llegado el auto a la sucursal donde va recoger el auto el cliente. El cliente va la sucursal y recoge su auto y firma de recibido.
<br><br><br>




<br><h1 align=center>PROBLEM�TICA</h1>
<br>
<br>-	No se cuenta con cuentas de sistema para los empleados.
<br>-	El sistema actual se vuelve lento cuando hay actualizaciones del software.
<br>-	Al software le hacen falta algunos campos para el llenado de informaci�n.
<br>-	El dise�o del software est� muy confuso
<br>-	El cliente le gustar�a ver d�nde est� su auto en tiempo real
<br>
<br>
<br><h1 align=center>OBJETIVOS </h1>
<br>un sistema para el manejo de control de autos, el cual incluir�: la creaci�n de cuentas de inicio de sesi�n para cada empleado, control de venta del producto; datos del auto y cliente, registro de sucursales, el manejo de transporte del carro, consultas de sucursales y empleados, realizar contrataciones y despidos de empleados, realizar los pagos de sueldos 
<br>
<br><h1 align=center>REQUERIMIENTOS </h1>
<br>-	Control de clientes
<br>-	Control de transacciones de cada sucursal.
<br>-	Control de empleados.
<br>-	Realizar consultas v�a web.
<br>-	Registro empleados
<br>-	Control de sucursales 
<br>-	Control de gerentes
<br>
<br>
<br>
<br><h1 align=center>PROPUESTAS </h1>
<br><h2 align=center>PROPUESTA 1: SOFTWARE SICA</h2>
<br>Es un software desarrollado en un lenguaje de programaci�n PHP Y HTTL el cual es la mejor opci�n para realizar las tareas necesarias de su empresa, ya est� adaptado a todas las necesidades actuales que se realizan ya que desde cualquier parte el cliente va poder ver la ubicaci�n del auto y as� no dar tantas vueltas a la sucursal: consultas, registr� de empleados y clientes, cuentas de inicio de sesi�n. Ideal tanto para peque�as y medianas empresas, SIF es una aplicaci�n muy profesional que te permite mantener una base de datos de tus clientes, empleados, sucursales y autos.
<br><h3 align=center>Requerimientos de desarrollo </h3>
<br><h4 >Hardware:</h4> 
<br>-	Contar con impresora que como m�nimo imprima a blanco y negro 
<br>-	Contar con una computadora que contenga como m�nimo un sistema operativo con Windows 7, tambi�n que esta tenga como m�nimo 2GB en memoria RAM y 120GB de memoria de almacenamiento
<br>-	Tener personal capacitado para la utilizaci�n de una computadora
<br><h4 >Software:</h4>
<br>-	Tener como m�nimo Windows 7 como sistema operativo
<br>-	Tener un antivirus eficiente 
<br>-	Tener una conexi�n a internet
<br><h3 align=center>Requerimientos funcionales</h3>
<br><h4 >Hardware:</h4>
<br>-	Contar con no Brakes
<br>-	Contar como m�nimo una computadora que contenga puerto rj45 o una tarjeta de red para la conexi�n remota, monitor, teclado, mouse, un navegador (Chrome, Firefox, Explorer), Como m�nimo 2gb de memoria RAM, Disco duro de 120gb m�nimo, Un procesador con una frecuencia mayor de 1GHz
<br>-	Tener al menos una impresora que imprima como m�nimo a blanco y negro.
<br>-	Contar con personal capacitado para el manejo de una computadora
<br><h4 >Software:</h4>
<br>-	Tener como m�nimo una versi�n de sistema operativo de Windows 7
<br>-	Utilizar un antivirus eficiente
<br>-	Tener una conexi�n a internet
<br>-	Contar un navegador (de preferencia google chorme)
<br>
<br>
<br>
<br><h3 align=center>Estudio de factibilidad </h3>
<br><h4 >Econ�mico:</h4>
<br>La empresa Sica tiene el sustento econ�mico para hacer su propio sistema con los apartados y servicios que necesiten acorde a los requerimientos y servicios del sistema.
<br><h4 >T�cnico:</h4>
<br>La empresa apoyo econ�mico cuenta con varios equipos los cuales son aptos para que el software tenga una funcionalidad correcta, estos se encuentran en buen estado y actualizados, as� tambi�n cuenta con un ambiente adecuado ya que cuenta con energ�a el�ctrica, impresoras para que el software funcione de la mejor forma.
<br><h4 >Operativo:</h4>
<br>El personal es joven y por lo tanto va ser capaz de aprender r�pido ya que est� acostumbrado a usar la tecnolog�a actual y la capacitaci�n ser� simple, adem�s cuentan con los equipos necesarios y con los requisitos para la �ptima ejecuci�n del programa. El sistema garantiza que va ser muy usado ya que va ahorrar tiempo de b�squedas, va mejorar la facilidad de pagos y de pr�stamos, lo m�s importante va a ser f�cil de usar para optimizar tareas y controlar sus procesos. Con este sistema garantiza la optimizaci�n de tiempos
<br>
<br><h2 align=center>PROPUESTA  2: VISIOCAR</h2>
<br>Visiocar es un software comercial para el control de los procesos administrativos de una financiera el cual es una gran opci�n, solo contiene los procesos b�sicos  y podr�a adaptarse de una forma correcta a la empresa. Por ser un sistema comercial, est� limitado con las funciones b�sicas como: Agregar y consultar cr�ditos /clientes y cobro de cuotas.   
<br><h3 align=center>Requerimientos de desarrollo</h3>
<br><h4 >Hardware:</h4> 
<br>-	Contar con impresora multifuncional
<br>-	Contar con una computadora que contenga como m�nimo 2GB en memoria RAM, 500GB de disco duro, procesador de m�nimo con 1.5Ghz
<br>-	Tener personal capacitado para la utilizaci�n de una computadora
<br><h4 >Software:</h4>
<br>-	Tener como m�nimo Windows 7 como sistema operativo
<br>-	Tener conexi�n a internet
<br>-	Contar con licencias de sistema operativo 
<br>-	un navegador (Chrome, Firefox, Explorer)
<br>
<br>
<br>
<br><h3 align=center>Requerimientos funcionales</h3>
<br><h4 >Hardware:</h4>
<br>-	Contar con energ�a el�ctrica y con no Brakes
<br>-	Contar como m�nimo una computadora que contenga , monitor, teclado, mouse, un servidor para almacenar la base de datos, Como m�nimo 4gb de memoria RAM, Disco duro de 500gb m�nimo, Un procesador con una frecuencia mayor de 1.5GHz
<br>-	un navegador (Chrome, Firefox, Explorer)
<br><h4 >Software:</h4>
<br>-	contar con el sistema operativo fedora
<br>-	Utilizar un antivirus eficiente
<br>
<br>
<br>
<br><h3 align=center>Estudio de factibilidad</h3>
<br><h4 >Econ�mico:</h4>
<br>La empresa apoyo econ�mico tiene el sustento econ�mico para comprar un software comercial puesto que ya tiene varios a�os laborando lo cual hace que cuente con el suficiente dinero para que se compre el software para emplear en esta empresa as� tambi�n como se encuentra asociada con otras financieras el ingreso de dinero es mucho mayor y facilita tener la cantidad necesarias para comprar dicho software.
<br>T�cnico:
<br>La empresa apoyo econ�mico cuenta con varios equipos los cuales son aptos para que el software Visiocar tenga una funcionalidad correcta ya que se encuentran en buen estado y se encuentran actualizadas  el aspecto de sistema operativo y programas que se utilizan, as� tambi�n cuenta con un ambiente adecuado ya que cuenta con energ�a el�ctrica, impresoras para que el software funcione de la mejor forma.
<br>Operativo:
<br>El personal es joven y por lo tanto va ser capaz de aprender r�pido ya que est� acostumbrado a usar la tecnolog�a actual y la capacitaci�n parece que va ser simple adem�s cuentan con los equipos necesarios que cuentan con los requisitos para el optima ejecuci�n del programa as� como tambi�n el software contiene manuales para facilitar el uso de dicho software y no tener ning�n problema.
<br>
<br>
<br>
<br><h2 align=center>PROPUESTA  3: PRESTENT </h2>
<br>Es un software desarrollado en el entorno de programaci�n de visual estudio el cual es una buena opci�n,  es un programa que utiliza muy poca memoria, requieres de actualizaciones constantes para mejorar su compatibilidad. Llevar� un registro preciso de sus cuentas por cobrar y por pagar y cuenta con algunos reportes que podr� crearse en formato pdf.
<br><h3 align=center>Requerimientos de desarrollo</h3>
<br><h4 >Hardware:</h4> 
<br>-	Contar con impresora que imprima a color y a blanco y negro
<br>-	Contar con una computadora que contenga monitor, mouse, teclado, lector de huella ,procesador mayor a 1.5Ghz 
<br>-	Tener personal capacitado para la utilizaci�n de una computadora
<br><h4 >Software:</h4>
<br>-	Tener como m�nimo Windows XP como sistema operativo
<br>-	Contar con las licencias del sistema operativo
<br>-	Tener un antivirus y contar con su licencia ?
<br><h3 align=center>Requerimientos funcionales</h3>
<br><h4 >Hardware:</h4>
<br>-	Contar con no Brakes
<br>-	Contar como m�nimo con dos computadoras con monitor, teclado, mouse.
<br>-	Contar con personal capacitado para el manejo de una computadora
<br>-	Que la computadora tenga como m�nimo 1gb de memoria 
<br>-	disco duro de 120gb m�nimo
<br>-	un procesador con una frecuencia mayor de 1GHz
<br><h4 >Software:</h4>
<br>-	Tener como m�nimo una versi�n de sistema operativo de Windows XP
<br>-	Utilizar un antivirus eficiente
<br><h3 align=center>Estudio de factibilidad</h3>
<br><h4 >Econ�mico:</h4>
<br>La empresa  cuenta con suficiente capital para la adquisici�n del software ya que como lleva tiempo trabajando si cuenta con el dinero necesario para pagar dicho software
<br><h4 >T�cnico:</h4>
<br>La empresa apoyo econ�mico cuenta con varios equipos de c�mputo los cuales son equipos reciente al igual que tambi�n cuentan con impresoras de distintos tipos lo que hace que el software si se pueda desempe�ar de la mejor manera
<br>
<br><h4 Operativo:</h4>
<br>El personal de la empresa se encuentra capacitado para el uso de una computadora ya que se encuentran trabajando con un software financiero y ya saben c�mo es que se debe de trabajar con este tipo de software
<br>
<h1 align=center>CONCLUSIONES</h1> <br>
Las opciones de un sistema para el control de actividades administrativas de empresas con giro de ventas son muy amplias en el mercado, pero sin duda, SICA que se elabor� basado a todas las necesidades de la empresa y si realizo para que no se pase por alto ninguna actividad de suma importancia, es el software que va acuerdo con cada una de las necesidades de estas empresas, por ser un sistema de alta calidad y competitividad. Adem�s est� desarrollado en un servidor web el cual facilitara y optimizara los procesos como al cliente como el empleado y a la directiva ya que ayudar� a ver los datos de su empresa desde cualquier parte siempre y cuando tenga conexi�n a internet y un navegador  (Chrome, Firefox, Explorer).
<br>	
?<br>
<br><h1 align=center>ANEXOS</h1>
<br><h3> Entrevista</h3>
<br>Objetivo de la entrevista: Recabar informaci�n de los procesos administrativos de la empresa.
<br>1. �En qu� �reas se encuentra dividida la empresa?
<br>Est� dividida en las �reas de f�brica y concesionarias.
<br>2. �Cu�les son las actividades que se realizan en la empresa?
<br>Fabricaci�n de autos y venta de autos 
<br>3. �Cu�l es la actividad a la que se le dedica m�s tiempo?
<br>Al transporte de autos de sucursal a sucursal
<br>4. �C�mo se administra la informaci�n en cada �rea?
<br>En sistema se refleja las actividades que se realizan a diario, el avance que se tienen en cuanto a metas,  se llevan registros en carpetas de reportes de todas las actividades.
<br>5. �C�mo realizan una venta?
<br>Se le pide los datos del auto para luego los del el
<br>6. �Cu�les son los datos que se registran de cada cliente?
<br>Solo su nombre completo para luego asignarle un id de cliente, id sucursal, id de auto y una contrase�a 
<br>7. �Cu�les son los datos que le piden al cliente de un pedido?
<br>Tipo de auto, color, Numero de puertas, tipo de trasmisi�n, tipo de combustible, estado, ubicaci�n y el id del auto y el de sucursal son asignados por el empleado
<br>8. �Qu� facilidades de informe de entrega del producto le brindan al cliente?
<br>Casi nada ya que el cliente tiene que estar yendo a la sucursal solo para preguntar si ya llego su auto
<br>


<br>"

?>
<br><h2>Diagrama de base de datos</h2>
<img src="images/BD.png" width="900" height="600" hspace="150" vspace="5" border="0" align="left">
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br><h2>Diccionario de base de datos</h2>
<img src="images/DicBD.png" width="1000" height="800" hspace="150" vspace="5" border="0" align="left">