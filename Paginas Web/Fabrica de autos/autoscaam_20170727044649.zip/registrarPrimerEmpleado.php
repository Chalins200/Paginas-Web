<html>
<body BGCOLOR="#4682B4">
<MARQUEE BGCOLOR="#4682B4">..:: Registrar Empleado ::..</h1></MARQUEE>



<head>
	<title>Registrar Empleado</title>
	
</head>
<form action=registrarEmpleado22.php method=POST>
<?php
echo "<h1>";

echo "<TABLE border=0 width=250 align=left> <TR> <TD width=50 align=right> Id_Empleado: </TD> <TD width=50 align=center> <input type=text name=IdEmpleado></TD></TR>";
	
	echo "<TR> <TD width=50 align=right> Nombre: </TD> <TD width=50 align=center>  <input type=text name=Nombre></TD></TR>";
	
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);
$sucursal=$_COOKIE['Nueva_Sucursal'];

	$sql2="select * from Sucursales";
	$r2=mysql_query($sql2,$c);
	
	echo "<TR> <TD width=50 align=right> Sucursal: </TD> <TD width=50 align=left> {$_COOKIE['Nueva_Sucursal']} </TD></TR>";
	
	echo "<TR> <TD width=50 align=right> Tipo: </TD> <TD width=50 align=left>   <select name=Tipo>";
	echo "<option>Gerente</option>";
	echo "<option>Secretaria</option>";
	echo "</select></TD></TR>";
	
	echo "<TR> <TD width=50 align=right> Contrase�a: </TD> <TD width=50 align=center>  <input type=text name=Contrase�a></TD></TR>";
	
	
	echo "<TR> <TD width=50 align=right> </TD> <TD width=50 align=center> <input type=submit value=AGREGAR></TD></TR></TABLE>";
	echo "</h1>";
?>
</form>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>

</body>

</html>

		
