<html>
<body BGCOLOR="#4682B4">
<MARQUEE BGCOLOR="#4682B4">..:: Registrar Empleado ::..</h1></MARQUEE>

<head>
	<title>Registrar Empleado</title>
	
</head>


<?php	
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);
	
	$sql2=mysql_query("insert into Empleados(Id_Empleado,Nombre,Id_Sucursal,Tipo,Contrase�a)
	values('{$_POST['IdEmpleado']}','{$_POST['Nombre']}','{$_COOKIE['Nueva_Sucursal']}','{$_POST['Tipo']}','{$_POST['Contrase�a']}')",$c);
	echo "Empleado registrado correctamente!";
	
?>

<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>