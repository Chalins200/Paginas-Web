<html>
<body>

<form action=generarCliente.html method=POST>
<?php

$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);


	$sql2="select * from Sucursales where Id_Sucursal='{$_COOKIE['Id_Sucursal']} '";
	$r2=mysql_query($sql2,$c);
	$arr2=mysql_fetch_array($r2);
	$id_auto = $arr2['Id_Auto'];
	setcookie("Auto", "{$_POST['SV1']}", time()+3600);
	

	$r=mysql_query("insert into Autos(Id_Auto,Tipo,Color,Numero_Puertas,Transmision,Conbustible,Ubicacion,Id_Sucursal,Estado,Comentario)
	values('{$_POST['SV1']}','{$_POST['Tipo']}','{$_POST['Color']}',{$_POST['NPuertas']},'{$_POST['Transmision']}','{$_POST['Combustible']}','{$arr2['Ubicacion']}','{$_COOKIE['Id_Sucursal']} ','En Proceso','{$_POST['Comentario']}')",$c);  
                                              
	//echo "Registro Almacenado Correctamente<br>";
	echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=generarCliente.html'><body>Espera, te vamos a redireccionar </body></html>";
	
?>
</form>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>;
</body>
</html>