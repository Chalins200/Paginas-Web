<html>
<BODY BGCOLOR="#4682B4">
<FONT FACE="Impact">
<MARQUEE BGCOLOR="#4682B4">..:: Modificacion de Clientes::..</h1></MARQUEE><p>

</p>
</FONT>
<body>
<?php
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

$sql="select * from Clientes where Id_Cliente='{$_POST['idCliente']}'";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);     
      
	echo "<form action=modificarClientes3.php method=POST>";
	echo " <input type=hidden name=idC value={$arr['Id_Cliente']}>";
	echo "Nombre       : <input type=text name=nom value={$arr['Nombre']}><br><br>";
	echo "Contrase�a      : <input type=text name=con value={$arr['Contrase�a']}><br><br>";
	
	
	echo "<input type=submit value=Modificar>";


?>

<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>

