<html>
<body BGCOLOR="#4682B4">
<head>
<MARQUEE BGCOLOR="#4682B4">..:: Consulta Vehiculo::..</h1></MARQUEE>	

</head>



<?php
echo "<h1 align=center>Fabricadora de Vehiculos DinaCorp</h1>";
echo "<hr width=500><hr width=400><hr width=300><hr width=200><hr width=100>";
$Servidor = $_COOKIE['Servidor'];
$Usuario = $_COOKIE['Usuario'];
$Contrase�a = $_COOKIE['Contrase�a'];     
$c=mysql_connect("$Servidor","$Usuario","$Contrase�a");
mysql_select_db("$Usuario",$c);

$sql="select * from Autos where Id_Auto='{$_POST['idAuto']}'";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r); 

$sql2="select * from Clientes where Id_Auto='{$_POST['idAuto']}'";
$r2=mysql_query($sql2,$c);
$Cliente=mysql_fetch_array($r2); 

echo "<h1>ID del Auto: ".$arr['Id_Auto']."<br>";
echo "Cliente: ".$Cliente['Nombre']."<br>";
echo "Sucursal: ".$arr['Id_Sucursal']."<br>";
echo "Ubicacion Actual: ".$arr['Ubicacion']."<br>";
echo "Estado: ".$arr['Estado']."<br><br></h1>";

	
	?>
</form>


<br>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>