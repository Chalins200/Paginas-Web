<html>
<body BGCOLOR="#4682B4">
<head>
<MARQUEE BGCOLOR="#4682B4">..:: Consulta Vehiculo::..</h1></MARQUEE>	

</head>

<form action=consultasVehiculo2.php method=POST>

<?php
echo "<h1 align=center>Fabricadora de Vehiculos DinaCorp</h1>";
echo "<hr width=500><hr width=400><hr width=300><hr width=200><hr width=100>";

echo "<form action=ConsultaCliente.php method=POST>";
echo "<h1>	Identificador de auto: <input type=text name=idAuto><br>";
echo "<input type=submit value=Buscar> </h1>";
	?>
</form>


<br>
<center><a href="javascript:history.back(-1);" title="Ir la p�gina anterior">Volver</a>
</body>
</html>