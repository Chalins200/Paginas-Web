<?php
include("conexion.php");
?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8 with BOM">
  <title>Mostrar Habitaciones</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="css/style.css">

</head>

<body>

<!-- Navbar -->
<div class="w3-top">
<ul class="w3-navbar w3-black w3-card-2 w3-left-align">
  <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Inicio</a>   
  </li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Medicamentos <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Medicamento.php">Registrar Medicamento</a>
      <a href="Consultar-Medicamento.php">Medicamentos por nombre</a>
      <a href="Consultar-Medicamento-Compuesto.php">Medicamentos por compuesto</a>
      <a href="Consultar-Medicamento-Marca.php">Medicamentos por marca</a>
     </div>
</li>
  
<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Consultorios <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Consultorio.php">Registrar Consultorio</a>
      <a href="Consultar-Consultorio.php">Mostrar Consultorio</a>
      <a href="Rentar-Consultorio.php">Rentar Consultorio</a>
     </div>
</li>  

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Habitaciones <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Habitacion.php">Registrar Habitaciones</a>
      <a href="Consultar-Habitacion.php">Mostrar Habitaciones</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Doctores <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Doctor.php">Registrar Doctores</a>
      <a href="Consultar-Doctor.php">Mostrar Doctores</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Empleados <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Empleado.php">Registrar Vendedor</a>
      <a href="Consultar-Empleado.php">Mostrar Vendedores</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Entradas/Salidas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
       <a href="consultaVentas.php">Mostrar Entradas</a>
      <a href="consultarCompras.php">Mostrar Salidas</a>
     </div>
</li>

 <li class="w3-hide-small w3-dropdown-hover">
    <a href="cerrarsesion.php" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesion</a>
  </li>
</ul>
</div>

<body>
  <br><br><br>
  <div class="card">
    <h1 class="title">Lista de habitaciones</h1>
        <div class="bar"></div>
        <div class="input-container">
        <center>
<table style="width:70%; border: 1px solid black; border-collapse: collapse; padding:25px;">
    <tr>
    <td style="background-color: black; color: white;">ID Habitacion</td>
    <td style="background-color: black; color: white;">Costo</td>
    <td style="background-color: black; color: white;">Tipo</td>
     <td style="background-color: black; color: white;">Ocupado por</td>
    
    </tr>
    
 <?php
    $sql= "select * from Habitaciones";
    $r2=mysql_query($sql,$c);
      while($arr2=mysql_fetch_array($r2))
      {
      echo "<tr><td>{$arr2['Id_habitacion']}</td>
      <td>{$arr2['Costo']}</td>
      <td>{$arr2['Tipo']}</td>
      <td>{$arr2['Id_paciente']}</td></tr>";
      }
    echo "</select><br>";

  echo "</div>";

  ?>
  </table>
  </center>
  </div>
</body>
</html>
