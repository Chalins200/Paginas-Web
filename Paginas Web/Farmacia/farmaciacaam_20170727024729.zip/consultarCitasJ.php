<?php
include('funcionesJ.php');
$doctor=$_GET["doctor"];


if($resultset=getSQLResultSet("SELECT * FROM Citas where Id_doctor='$doctor'")){
	while ($row = $resultset->fetch_array(MYSQLI_NUM)){
		echo json_encode($row);
	}
}

?>