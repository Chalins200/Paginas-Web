<!DOCTYPE html>

<head>
  <meta charset="UTF-8 with BOM">
  <title>Registrar Habitaciones</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   
  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>



<body>

<!-- Navbar -->http://miarroba.st/094/iconos/vacio.gif
<div class="w3-top">
<ul class="w3-navbar w3-black w3-card-2 w3-left-align">
  <li class="w3-hide-medium w3-hide-large w3-opennav w3-right">
    <a class="w3-padding-large" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
  </li>
  
 <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Inicio <i class="fa fa-caret-down"></i></a>   
  </li>

 <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesion <i class="fa fa-caret-down"></i></a>
  </li>
</ul>
</div>

<body>
  
<!-- Mixins-->
<!-- Pen Title-->

<table>
<tr>

</tr>
</table>
<div class="container">
  <div class="card"></div>
  <div class="card">
  
    <h1 class="title">Registro de habitaciones</h1>
    
    <form method="POST" action="Comprar-Medicamento1.php">
      <div class="input-container">
        <input type="text" id="id_habitacion" name="id_habitacion" required="required"/>
        <label for="Username">ID Habitaci�n</label>
        <div class="bar"></div>
      </div>      
      <div class="input-container">
        <input type="text" id="costo" name="costo" required="required"/>
        <label for="Username">Costo</label>
        <div class="bar"></div>
      </div>
  	<div class="input-container">
  	<h1>Tipo de habitacion</h1>
  	<select id="tipo" name="tipo" required="required">
	<option value ='A' >A</option>
	<option value ='B' >B</option>
	<option value ='C' >C</option>
	<option value ='D' >D</option>
	</select>
        <div class="bar"></div>
      </div>
     
  
      <br>
      <br>
  
      <div class="button-container">
        <button><span>Registrar</span></button>
      </div>
      
    </form>
    
</body>
</html>