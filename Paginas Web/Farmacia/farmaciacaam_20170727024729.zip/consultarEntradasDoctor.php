<?php include("conexion.php");

$doctor=$_GET['doctor'];
 ?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8 with BOM">
  <title>Entradas Doctor</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   
  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>



<body>

<!-- Navbar -->http://miarroba.st/094/iconos/vacio.gif
<div class="w3-top">
<ul class="w3-navbar w3-black w3-card-2 w3-left-align">
  <li class="w3-hide-medium w3-hide-large w3-opennav w3-right">
    <a class="w3-padding-large" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
  </li>
  
 <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Inicio <i class="fa fa-caret-down"></i></a>   
  </li>

 <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesion <i class="fa fa-caret-down"></i></a>
  </li>
</ul>
</div>

<body>
  
<!-- Mixins-->
<!-- Pen Title-->

<table>
<tr>

</tr>
</table>
  <div class="card"></div>
  <div class="card">
  
    <h1 class="title">Entradas</h1>
    <h1 align=center> </h1><br>
    

    <div class="input-container">
    
        <table style="width:100%; border: 1px solid black;"><th>Id Entrada</th><th>Detalle</th><th>Cita</th><th>Monto</th>
        
        	<?php
        	$sen="select * from Citas where Id_doctor='$doctor'";
        	$r=mysql_query($sen);
        	while($c=mysql_fetch_array($r)){
        		$sen2="select * from EntradasDoctor where Id_cita={$c['Id_cita']}";
        		$r2=mysql_query($sen2);
        	while($c2=mysql_fetch_array($r2)){
        	echo "
      
        <tr>
        	<td align=center>{$c2['Id_entrada']}</td>
        	<td align=center>{$c2['Detalle']}</td>
        	<td align=center>{$c2['Id_cita']}</td>
        	<td align=center>$ {$c2['Total']}</td>
        	</tr> 
        	";
        	}
        	}
        	
        	?>
        
                </table>
      </div>
        
    <!--  <div class="input-container">
        <input type="text" name="id_paciente">
        <label for="Username">Paciente</label>
        <div class="bar"></div>
      </div>     -->
  
      <div class="button-container">
        <button><span>Agendar</span></button>
      </div>
      
    
    
</body>
</html>