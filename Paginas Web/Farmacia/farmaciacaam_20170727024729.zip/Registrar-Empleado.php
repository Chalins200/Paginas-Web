<?php
include("conexion.php");
?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8 with BOM">
  <title>Registrar Usuarios</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="css/style.css">

</head>

<body>

<!-- Navbar -->
<div class="w3-top">
<ul class="w3-navbar w3-black w3-card-2 w3-left-align">
 <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Inicio</a>   
  </li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Medicamentos <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Medicamento.php">Registrar Medicamento</a>
      <a href="Consultar-Medicamento.php">Medicamentos por nombre</a>
      <a href="Consultar-Medicamento-Compuesto.php">Medicamentos por compuesto</a>
      <a href="Consultar-Medicamento-Marca.php">Medicamentos por marca</a>
     </div>
</li>
  
<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Consultorios <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Consultorio.php">Registrar Consultorio</a>
      <a href="Consultar-Consultorio.php">Mostrar Consultorio</a>
      <a href="Rentar-Consultorio.php">Rentar Consultorio</a>
     </div>
</li>  

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Habitaciones <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Habitacion.php">Registrar Habitaciones</a>
      <a href="Consultar-Habitacion.php">Mostrar Habitaciones</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Doctores <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Doctor.php">Registrar Doctores</a>
      <a href="Consultar-Doctor.php">Mostrar Doctores</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Empleados <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Empleado.php">Registrar Vendedor</a>
      <a href="Consultar-Empleado.php">Mostrar Vendedores</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Entradas/Salidas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
       <a href="consultaVentas.php">Mostrar Entradas</a>
      <a href="consultarCompras.php">Mostrar Salidas</a>
     </div>
</li>

 <li class="w3-hide-small w3-dropdown-hover">
    <a href="cerrarsesion.php" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesion</a>
  </li>
</ul>
</div>

<body>
  
<!-- Mixins-->
<!-- Pen Title-->

<table>
<tr>

</tr>
</table>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Registro de usuarios</h1>
    <form method="POST" action="Registrar-Empleado.php">
      <div class="input-container">
        <input type="text" id="id_User" name="id_User" required="required"/>
        <label for="Username">ID de Usuario</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="text" id="nombreUser" name="nombreUser" required="required"/>
        <label for="Username">Nombre del usuario</label>
        <div class="bar"></div>
      </div>
        
       <div class="input-container">
        <input type="password" id="clave" name="clave" required="required"/>
        <label for="Username">Contrase�a</label>
        <div class="bar"></div>
      </div>
    
      <br>
      <br>
  
      <div class="button-container">
        <button><span>Registrar</span></button>
      </div>
      
    </form>
    
</body>
</html>

<?php
if($_POST['id_User'] == null){

}else{
$sql2= "INSERT INTO Usuarios VALUES ('{$_POST['id_User']}','{$_POST['nombreUser']}','Empleado','','{$_POST['clave']}')";
$r2=mysql_query($sql2,$c);
echo "<center> EL EMPLEADO SE AGREGO CON EXITO </center>";
}
?>