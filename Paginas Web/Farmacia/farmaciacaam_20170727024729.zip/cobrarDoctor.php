<?php 
include("conexion.php");
session_start();

$nomDoc=$_SESSION['Nombre'];
$idDoc=$_SESSION['id_usuario'];
$tipoDoc=$_SESSION['TipoUser'];

//echo "$nomDoc<br>$idDoc<br>";

$fecha_actual=date("Y-m-d"); 
$hora_actual=date("H").":".date("i");

$sen="insert into EntradasDoctor (Id_entrada,Detalle,Id_cita,Fecha,Total,Id_doctor) 
values ('','{$_POST['detalle']}','{$_POST['citaa']}','$fecha_actual',{$_POST['costo']});";

$sen2="update Citas set Estado='Atendida' where Id_cita='{$_POST['citaa']}'";

mysql_query($sen);
mysql_query($sen2);

echo $sen."<br>";
echo $sen2."<br>";
echo "<br> {$_POST['archivo']}";


$file = fopen("./expedientes/{$_POST['archivo']}.txt", "a");

fwrite($file, "                                                                     " . PHP_EOL);
fwrite($file, "--------------------$fecha_actual $hora_actual-----------------------" . PHP_EOL);
fwrite($file, "Area: {$tipoDoc}". PHP_EOL);
fwrite($file, "Doctor: {$nomDoc}". PHP_EOL);
fwrite($file, "Detalle: {$_POST['detalle']}" . PHP_EOL);

fclose($file);

header("location: cobrarCitaF.php?doctor={$_SESSION['id_usuario']}");

?>