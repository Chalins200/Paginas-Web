<?php
include("conexion.php");
include('ConexionG.php');
session_start();
?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8 with BOM">
  <title>Compra de Medicamento</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="css/styleautocomplete.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
  
</head>



<body>

<!-- Navbar -->
<div class="w3-top">
  <ul class="w3-navbar w3-black w3-card-2 w3-left-align">
       <li class="w3-hide-small w3-dropdown-hover">
    <a href="Doctor.php" class="w3-hover-none w3-padding-large" title="More">Inicio</a>   
  </li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Citas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="registrarCitaF.php">Agendar cita</a>
      <a href="cobrarCitaF.php?doctor=<?php session_start();?><?php  echo $_SESSION['id_usuario'];  ?>">Mostrar citas</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Medicamentos <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="#">Vender Medicamento</a>
      <a href="Consultar-Medicamento.php">Medicamentos por nombre</a>
      <a href="Consultar-Medicamento-Compuesto.php">Medicamentos por compuesto</a>
      <a href="Consultar-Medicamento-Marca.php">Medicamentos por marca</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Pacientes <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Paciente.php">Registrar paciente</a>
      <a href="Consultar-Paciente.php">Mostrar pacientes</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Entradas/Salidas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Consultar-Entradas-Doctor.php">Mostrar Entradas</a>
      <a href="Consultar-Salidas-Doctor.php">Mostrar Salidas</a>
      <a href="Pagar-Renta-Doctor.php">Pagar Renta</a>
     </div>
</li>

 <li class="w3-hide-small w3-dropdown-hover">
    <a href="cerrarsesion.php" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesi�n</a>
  </li>
</ul>
</ul>
</div>

<body>
  
<!-- Mixins-->
<!-- Pen Title-->

<table>
<tr>

</tr>
</table>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Salidas por periodo</h1>
    <div class="content">            
             <form method="POST" action="Consultar-Salidas-Doctor.php">
               <div class="input_container">
               
                <label for="Username">Fecha inicio:</label><br>
                    <ul id="list_id"></ul><br>
                    <input type="date" name='fechainicio' id="fechainicio"> <br><br>
                    
                    <label for="Username">Fecha fin:</label><br>
                    <ul id="list_id"></ul><br>
                    <input type="date" name='fechafin' id="fechafin"><br><br>
                    
                    <input type='submit' value='Consultar'><br><br>
                </div>
                <br><br><br><br><br><br><br><br><br><br>
            </form>
        </div>
     <?php
     if($_POST['fechainicio'] == null){

}else{
 ?>
    
        <center>
<table style="width:70%; border: 1px solid black; border-collapse: collapse; padding:25px;">
    <tr>
    <td style="background-color: black; color: white;">Detalle</td>
    <td style="background-color: black; color: white;">Fecha</td>
    <td style="background-color: black; color: white;">Total</td>
    
    </tr>
    
<?php
    $sql= "select * from SalidasDoctor Where Id_doctor='{$_SESSION['id_usuario']}' AND Fecha  between '{$_POST['fechainicio']}' AND '{$_POST['fechafin']}' ";
    $r2=mysql_query($sql,$c);
      while($arr2=mysql_fetch_array($r2))
      {
      echo "<tr><td>{$arr2['Detalle']}</td>
      <td>{$arr2['Fecha']}</td>
      <td>$ {$arr2['Total']}</td></tr>";
      }
    echo "</select><br>";

  echo "</div>";

  ?>
  </table>
  <?php
   $sql= "select SUM(Total) as SumaTotal from SalidasDoctor Where Id_doctor='{$_SESSION['id_usuario']}' AND Fecha  between '{$_POST['fechainicio']}' AND '{$_POST['fechafin']}' ";
    $r2=mysql_query($sql,$c);
      while($arr2=mysql_fetch_array($r2))
      {
      echo "Total: $ {$arr2['SumaTotal']}";
      }
  ?>
  </center> 
<?php
}
?>
      <br>
      <br>
  
 <form method="POST" action="Consultar-Salidas-Doctor.php">
 <input type="hidden" name="consulta" value="si">
      <div class="button-container">
        <button><span>Mostrar todos</span></button>
      </div>
      
    </form>
 <?php
if($_POST['consulta'] == null){

}else{
 ?>
    
        <center>
<table style="width:70%; border: 1px solid black; border-collapse: collapse; padding:25px;">
    <tr>
    <td style="background-color: black; color: white;">Detalle</td>
    <td style="background-color: black; color: white;">Fecha</td>
    <td style="background-color: black; color: white;">Total</td>
    
    </tr>
    
 <?php
    $sql= "select * from SalidasDoctor WHERE Id_doctor='{$_SESSION['id_usuario']}'";
    $r2=mysql_query($sql,$c);
      while($arr2=mysql_fetch_array($r2))
      {
      echo "<tr><td>{$arr2['Detalle']}</td>
      <td>{$arr2['Fecha']}</td>
      <td>$ {$arr2['Total']}</td></tr>";
      }
    echo "</select><br>";

  echo "</div>";

  ?>
  </table>
  
  <?php
   $sql= "select SUM(Total) as SumaTotal from SalidasDoctor WHERE Id_doctor='{$_SESSION['id_usuario']}'";
    $r2=mysql_query($sql,$c);
      while($arr2=mysql_fetch_array($r2))
      {
      echo "Total: $ {$arr2['SumaTotal']}";
      }
  ?>
  </center>
  
  
<?php
}
?>
</body>
</html>