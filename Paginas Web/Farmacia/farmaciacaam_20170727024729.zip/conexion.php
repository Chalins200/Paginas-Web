<?php 
$c = mysql_connect("mysql.webcindario.com", "farmaciacaam","mitocondrias200"); 
mysql_select_db("farmaciacaam", $c); 
?> 