<?php
include("conexion.php");
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8 with BOM">
  <title>Clinica Caam</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   <link rel="stylesheet" href="css/estilos.css">
  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>
  
<!-- Mixins-->
<!-- Pen Title-->
<div class="pen-title">
<td><img src ="http://edmix.upt.edu.mx/licenciaturas/logo.png" width="50" height="50"></td>
  <h1>Farmacia CAAM</h1>
</div>
<table>
<tr>

</tr>
</table>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Inicio de Sesi�n</h1>
    <form method="POST" action="index.php">
      <div class="input-container">
        <input type="text" id="Username" name="Nombre" required="required"/>
        <label for="Username">Usuario</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="password" id="Password" name="Clave" required="required"/>
        <label for="Password">Contrase�a</label>
        <div class="bar"></div>
      </div>
      
      <div class="button-container">
        <button><span>Iniciar Sesi�n</span></button>
      </div>
      
    </form>
  
  <script src="js/formulario.js"></script>
</div>
</body>
</html>
<?php
session_start();
echo $_POST['Nombre'];
echo $_POST['Clave'];
    $sql= "select * from Usuarios Where Id_usuario='{$_POST['Nombre']}' AND clave='{$_POST['Clave']}'";
    $r2=mysql_query($sql,$c);
    $res=mysql_fetch_array($r2);
$_SESSION['id_usuario'] = $res['Id_usuario'];
$_SESSION['Nombre'] = $res['Nombre'];
$_SESSION['TipoUser'] = $res['Tipo_usuario'];
$_SESSION['TipoDoctor'] = $res['Tipo_Doctor'];
    
	if(strcmp($res['Tipo_usuario'],"Doctor")== 0){
	header("location:Doctor.php");
	echo "Doctor";
	}
	if(strcmp($res['Tipo_usuario'],"Empleado")== 0){
	header("location: Farmacia.php");
	echo "Farmacia";
	}
	if(strcmp($res['Tipo_usuario'],"Admin")== 0){
	header("location: Clinica.php");
	echo "Clinica";
	}else{ echo "error"; }
	
  ?>
