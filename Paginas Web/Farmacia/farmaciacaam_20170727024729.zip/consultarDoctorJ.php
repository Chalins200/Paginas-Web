<?php
include('funcionesJ.php');
$doctor=$_GET["doctor"];


if($resultset=getSQLResultSet("SELECT * FROM Usuarios where Id_usuario='$doctor'")){
	while ($row = $resultset->fetch_array(MYSQLI_NUM)){
		echo json_encode($row);
	}
}

?>