<?php
// PDO connect *********
require_once('ConexionG.php');
$keyword = '%'.$_POST['keyword'].'%';
$sql = "SELECT * FROM Medicamento WHERE Nombre LIKE (:keyword) OR Compuesto LIKE (:keyword) OR Marca LIKE (:keyword) ORDER BY Nombre ASC LIMIT 0, 10";
$query = $pdo->prepare($sql);
$query->bindParam(':keyword', $keyword, PDO::PARAM_STR);
$query->execute();
$list = $query->fetchAll();
foreach ($list as $rs) {
	// put in bold the written text
	$Mnombre = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'</b>', $rs['Nombre']);
	$Mcompuesto = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'</b>', $rs['Compuesto']);
	$Mmarca = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'</b>', $rs['Marca']);
	// add new option
	echo '<li onclick="set_item(\''.str_replace("'", "\'", $rs['Marca']).'\')">'.$Mmarca.'</li>';
	echo '<li onclick="set_item(\''.str_replace("'", "\'", $rs['Compuesto']).'\')">'.$Mcompuesto.'</li>';
    echo '<li onclick="set_item(\''.str_replace("'", "\'", $rs['Nombre']).'\')">'.$Mnombre.'</li>';
}
?>