function objetoAjax(){
		var xmlhttp = false;
		try {
			xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
�
			try {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (E) {
				xmlhttp = false; }
		}
�
		if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
		��xmlhttp = new XMLHttpRequest();
		}
		return xmlhttp;
	}
	
	function MostrarConsulta(){
	//Recogemos los valores introducimos en los campos de texto
		//medicamento = document.formulario.key.value;
�
�������� //Aqu� ser� donde se mostrar� el resultado
		marca = document.getElementById('count');

�              medicamento = document.formulario.key.value;
		//instanciamos el objetoAjax
		ajax = objetoAjax();
�
		//Abrimos una conexi�n AJAX pasando como par�metros el m�todo de env�o, y el archivo que realizar� las operaciones deseadas
		ajax.open("POST","Count2.php", true);
�
		//cuando el objeto XMLHttpRequest cambia de estado, la funci�n se inicia
		ajax.onreadystatechange = function() {
�
������������ //Cuando se completa la petici�n, mostrar� los resultados 
			if (ajax.readyState == 4){
�
				//El m�todo responseText() contiene el texto de nuestro 'consultar.php'. Por ejemplo, cualquier texto que mostremos por un 'echo'
				//marca.value = (ajax.responseText) 
				var obj = JSON.parse(ajax.responseText);			
                              marca.value = (obj.count);

                              saveData();
                             // doCompra();


			}
		} 
�
		//Llamamos al m�todo setRequestHeader indicando que los datos a enviarse est�n codificados como un formulario. 
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
�              ajax.send("&medicamento="+medicamento) 
		//enviamos las variables a 'consulta.php' 
		//ajax.send("&medicamento="+medicamento) 
	}

function enviarDatos(){
�
��������//Recogemos los valores introducimos en los campos de texto
		medicamento = document.formulario.key.value;
�
�������� //Aqu� ser� donde se mostrar� el resultado
		marca = document.getElementById('marca');
		nombre =document.getElementById('nombre');
		compuesto =document.getElementById('compuesto');
		stock =document.getElementById('cantidad');
		costo =document.getElementById('costo');
�
		//instanciamos el objetoAjax
		ajax = objetoAjax();
�
		//Abrimos una conexi�n AJAX pasando como par�metros el m�todo de env�o, y el archivo que realizar� las operaciones deseadas
		ajax.open("POST","Aux2.php", true);
�
		//cuando el objeto XMLHttpRequest cambia de estado, la funci�n se inicia
		ajax.onreadystatechange = function() {
�
������������ //Cuando se completa la petici�n, mostrar� los resultados 
			if (ajax.readyState == 4){
�
				//El m�todo responseText() contiene el texto de nuestro 'consultar.php'. Por ejemplo, cualquier texto que mostremos por un 'echo'
				//marca.value = (ajax.responseText) 
				var obj = JSON.parse(ajax.responseText);
                              marca.value = (obj.marca);
                              nombre.value = (obj.nombre);
                              compuesto.value = (obj.compuesto);
                              stock.value = (obj.stock);
                              costo.value = (obj.costo);

			}
		} 
�
		//Llamamos al m�todo setRequestHeader indicando que los datos a enviarse est�n codificados como un formulario. 
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
�
		//enviamos las variables a 'consulta.php' 
		ajax.send("&medicamento="+medicamento) 
�
} 


function doCompra(){
�
��������//Recogemos los valores introducimos en los campos de texto
		id = document.every.count.value;
		total = document.every.totall.value;
�		
�������� //Aqu� ser� donde se mostrar� el resultado
		marca = document.getElementById('marca');
�
		//instanciamos el objetoAjax
		ajax = objetoAjax();
�
		//Abrimos una conexi�n AJAX pasando como par�metros el m�todo de env�o, y el archivo que realizar� las operaciones deseadas
		ajax.open("POST","Compra2.php", true);
�
		//cuando el objeto XMLHttpRequest cambia de estado, la funci�n se inicia
		ajax.onreadystatechange = function() {�
                           if (ajax.readyState == 4){
�
				//El m�todo responseText() contiene el texto de nuestro 'consultar.php'. Por ejemplo, cualquier texto que mostremos por un 'echo'
				//marca.value = (ajax.responseText) 
				

			}
		} 
�
		//Llamamos al m�todo setRequestHeader indicando que los datos a enviarse est�n codificados como un formulario. 
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
�
		//enviamos las variables a 'consulta.php' 
		//document.cookie ='id='+id+'; expires=Thu, 2 Aug 2021 20:47:11 UTC; path=/'
		//document.cookie ='total='+total+'; expires=Thu, 2 Aug 2021 20:47:11 UTC; path=/'
		//ajax.send("&id="+id);
		ajax.send("&total="+total+"&id="+id);
} 


function makeDetail(id,nombre,cant,cost,sub){
�
��������//Recogemos los valores introducimos en los campos de texto
		
�������� //Aqu� ser� donde se mostrar� el resultado
		marca = document.getElementById('marca');
�
		//instanciamos el objetoAjax
		ajax = objetoAjax();
�
		//Abrimos una conexi�n AJAX pasando como par�metros el m�todo de env�o, y el archivo que realizar� las operaciones deseadas
		ajax.open("POST","addDetlle2.php", true);
�
		//cuando el objeto XMLHttpRequest cambia de estado, la funci�n se inicia
		ajax.onreadystatechange = function() {�
                           if (ajax.readyState == 4){
�
				//El m�todo responseText() contiene el texto de nuestro 'consultar.php'. Por ejemplo, cualquier texto que mostremos por un 'echo'
				//marca.value = (ajax.responseText) 
				

			}
		} 
�
		//Llamamos al m�todo setRequestHeader indicando que los datos a enviarse est�n codificados como un formulario. 
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
�
		//enviamos las variables a 'consulta.php' 
		//document.cookie ='id='+id+'; expires=Thu, 2 Aug 2021 20:47:11 UTC; path=/'
		//document.cookie ='total='+total+'; expires=Thu, 2 Aug 2021 20:47:11 UTC; path=/'
		//ajax.send("&id="+id);
		ajax.send("&id="+id+"&nombre="+nombre+"&cant="+cant+"&cost="+cost+"&sub="+sub);
}


function saveData(){
doCompra();
var count= $("#count").val();
//alert(count);

var nombre = document.datos_venta.elements["tabname[]"];
//alert(nombre.length);
var cantidad = document.datos_venta.elements["tabcant[]"];
var costo = document.datos_venta.elements["tabcost[]"];
var subtotal = document.datos_venta.elements["tabsub[]"];
for(i=1;i<costo.length;i++)
{

makeDetail(count,nombre[i].value,cantidad[i].value,costo[i].value,subtotal[i].value);
//alert(nombre[i].value);
//alert(cantidad[i].value);
//alert(costo[i].value);
//alert(subtotal[i].value);
}
$("#tabla").find("tr:gt(1)").remove();
$("#totall").val(null);
tot=0;
enviarDatos();

alert("Compra efectuada con �xito!");
}