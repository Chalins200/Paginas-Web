<?php

$dsn = 'mysql:dbname=clinicajmgo;host=mysql.webcindario.com';
$user = 'clinicajmgo';
$password = 'Sinestesia1996';

try{

	$pdo = new PDO(	$dsn, 
					$user,
					$password
					);
	

}catch( PDOException $e ){
	echo 'Error al conectar: ' . $e->getMessage();
}
