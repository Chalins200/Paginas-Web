<?php
require_once('ConexionG.php');
$id =$_POST["id"];
$nombre=$_POST["nombre"];
$cant=$_POST["cant"];
$cost=$_POST["cost"];
$sub=$_POST["sub"];
$query='INSERT INTO DetalleVenta (Id_entrada,Nombre,Cantidad,Costo,Total) VALUES(?,?,?,?,?)';
$statement = $pdo->prepare($query);
$statement->execute(array($id,$nombre,$cant,$cost,$sub));
$sql2 ="UPDATE Medicamento SET Cantidad=Cantidad -$cant WHERE Nombre='$nombre'";
$statement2 = $pdo->prepare($sql2);
$statement2->execute();

?>