<?php 
require_once('ConexionG.php');
$sql = "SELECT Count(*) FROM EntradasClinica";
$query = $pdo->prepare($sql);
$query->execute();
$list = $query->fetchAll();
$array = array();
foreach ($list as $rs) {
	// put in bold the written text
	$array['count'] = $rs['Count(*)']+1;
	// add new option
	
    
}
echo json_encode($array);
?>