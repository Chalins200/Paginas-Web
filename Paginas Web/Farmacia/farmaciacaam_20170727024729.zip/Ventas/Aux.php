<?php
require_once('ConexionG.php');
$key=$_POST['medicamento'];
$marca=null;
$nombre;
$componente;
$query="Select * FROM Medicamento WHERE Nombre='$key' OR Compuesto='$key'";
$statement = $pdo->prepare($query);
$statement->execute();
$results = $statement->fetchAll();
$array = array();
foreach($results as $rs)
    {
    
$array['marca'] = $rs['Marca'];
$array['nombre'] = $rs['Nombre'];
$array['compuesto'] = $rs['Compuesto'];
$array['costo'] = $rs['Precio'];
$array['stock'] = $rs['Cantidad'];


}


//Mostramos el resultado. Este 'echo' ser� el que recibir� la conexi�n AJAX
	echo json_encode($array);

?>