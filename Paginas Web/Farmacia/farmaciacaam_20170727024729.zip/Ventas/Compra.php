<?php
require_once('ConexionG.php');
$id =$_POST["id"];
$total=$_POST["total"];
$fecha=date("Y-m-d");
$query='INSERT INTO EntradasClinica (Id_entrada,Departamento,Fecha,Total) VALUES(?,?,?,?)';

$statement = $pdo->prepare($query);
$statement->execute(array($id,'Farmacia',$fecha,$total));

?>