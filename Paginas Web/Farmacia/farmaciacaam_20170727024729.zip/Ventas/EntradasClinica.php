<html>
<head>
<link rel="stylesheet" href="css/styleautocomplet.css" />
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<script src="try/mysqlwslib.js"></script>
<script language="JavaScript" type="text/javascript" src="js/ajax.js"></script>	
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/jquery-3.1.1.js" type="text/javascript"></script>
<script src="js/jquery-3.1.1.js" type="text/javascript"></script><script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>



<script>
var contLin;
function agregar() {
var nombre= $("#nombre").val();
���var tr, td, tabla;
���tabla = document.getElementById('tabla');
���tr = tabla.insertRow(tabla.rows.length);
���td = tr.insertCell(tr.cells.length);�
���td.innerHTML ='<input type="text" name="tabname[]" id="tabname" value="'+$("#nombre").val()+'" readonly="readonly">';
   td = tr.insertCell(tr.cells.length);
���td.innerHTML ='<input type="text" name="tabcant[]" id="tabcant" value="'+$("#cant").val()+'" readonly="readonly">' ;   
   td = tr.insertCell(tr.cells.length);
���td.innerHTML ='<input type="text" name="tabcost[]" id="tabcost" value="'+$("#costo").val()+'" readonly="readonly">';   
���td = tr.insertCell(tr.cells.length);
���td.innerHTML ='<input type="text" name="tabsub[]" id="tabsub" value="'+$("#cant").val()*$("#costo").val()+'" readonly="readonly">';
   suma();
�//��contLin++;

}
var tot=0;
function suma(){
tot=$("#cant").val()*$("#costo").val()+tot;
document.getElementById("totall").value=tot;
}
</script>

<script>


</script>

</head>

		<body>
		<!-- Navbar -->
<div class="w3-top">
<ul class="w3-navbar w3-black w3-card-2 w3-left-align">
  <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Inicio</a>   
  </li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Medicamentos <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
    <a href="EntradasClinica.php">Vender Medicamento</a>
      <a href="../Registrar-Medicamento.php">Registrar Medicamento</a>
      <a href="SalidasClinica.php">Comprar Medicamento</a>
      <a href="../Consultar-Medicamento-Farmacia.php">Medicamentos por nombre</a>
      <a href="../Consultar-Medicamento-Compuesto-Farmacia.php">Medicamentos por compuesto</a>
      <a href="../Consultar-Medicamento-Marca-Farmacia.php">Medicamentos por marca</a>
     </div>
</li>
 
 <li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesion</a>
  </li>
</ul>
</div>
		<br><br><br>
		<div class="container">
     
        <h1 class="main_title">Busqueda</h1>
        <div class="content">
                        <div class="input_container">
            <form name="formulario"  onSubmit="enviarDatos(); return false">
              
                <table align="center">
                <td><input type="text" name="key" id="keyword" placeholder="Buscar medicamento" onkeyup="autocomplet()">
                    <ul id="list_id"></ul>
                 </td>
                 <td> 
                   <font size="2" color="black"> <input type="submit" id="buscar" value="Consultar"></font>
                    </td>
                </table>
                    <br><br><br>
               <table align="center"> 
               <tr>
                 <td>
                 Nombre del medicamento: <input type="text" id="nombre" name="nombre" >
                  </td> 
                  <td>
                  Compuesto del medicamento: <input type="text" id="compuesto" name="compuesto" >
                  </td>
                   <td>
                   Costo del medicamento: <input type="text" id="costo" name="costo">
                  </td>
                   <td>
                   Stock: <input type="text" name="cantidad" id="cantidad">
                  </td>
               
               <td> Marca del medicamento: <input type="text" id="marca" name="marca"></td>
               </tr>    
               </table>            
                                 
            </form>
            <br><br><br>
            <form action="#" method="post">
            <table align="center">
            <td><input type="number" name="cant" id="cant" placeholder="cantidad" value="1">
    
                 </td>
                 <td> 
                  <font size="2" color="black"> <input type="button"  value="A�adir a venta" onclick="agregar()"  /> </font>
                    </td>
                </table>
            </form>
            

            </div>
        </div><!-- content -->    

    </div><!-- container -->


<div class="container">
     
        <h1 class="main_title">A&ntilde;adidos a venta</h1>
        <div class="content">
                
                <div class="input_container">

		
		<!--Tabla de ventas-->
		<form name="datos_venta">
		<table id="tabla" align="center" name="tabla">
			<!-- Cabecera de la tabla -->
			<thead>
				<tr>
					<th width="200px" align="left">Producto</th>
					<th width="150px" align="left">Cantidad</th>
					<th width="150px" align="left">$ Costo</th>
					<th width="150px" align="left">$ Subtotal</th>
				</tr>
			</thead>
		� <tr style="display:none">
			�<td><input type="text" name="tabname[]" id="tabname"  readonly="readonly"> </td>
			<td><input type="text" name="tabcant[]" id="tabname"  readonly="readonly"> </td>
			<td><input type="text" name="tabcost[]" id="tabname"  readonly="readonly"> </td>
			<td><input type="text" name="tabsub[]" id="tabname"  readonly="readonly"> </td>
   
                 </tr>
		</table>
		</form>

</div>
<div class="input_container">
<center>
<font size="6" color="black">
<form name="every">
<label for="total">$TOTAL</label>
� <input type="number" name="totall" id="totall" readonly="readonly"><br><br>
<input type="hidden" name="count" id="count">
</form>
<form onSubmit="MostrarConsulta(); return false">
<font size="2" color="black"><input type="submit"  value="Consumar venta" name="btnRecorrer" id="btnRecorrer"/></font>

</form>
</font>
</center>
</div>

</div></div>
		
		
</body>

</html>