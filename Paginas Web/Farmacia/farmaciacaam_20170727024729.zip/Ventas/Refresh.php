<?php
// PDO connect *********
require_once('ConexionG.php');
$keyword = '%'.$_POST['keyword'].'%';
$sql = "SELECT * FROM Medicamento WHERE Nombre LIKE (:keyword) ORDER BY Nombre ASC LIMIT 0, 10";
$query = $pdo->prepare($sql);
$query->bindParam(':keyword', $keyword, PDO::PARAM_STR);
$query->execute();
$list = $query->fetchAll();
foreach ($list as $rs) {
	// put in bold the written text
	$Mnombre = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'</b>', $rs['Nombre']);
	// add new option
	
    echo '<li onclick="set_item(\''.str_replace("'", "\'", $rs['Nombre']).'\')">'.$Mnombre.'</li>';
}

$sql2 = "SELECT * FROM Medicamento WHERE Compuesto LIKE (:keyword) ORDER BY Compuesto ASC LIMIT 0, 10";
$query2 = $pdo->prepare($sql2);
$query2->bindParam(':keyword', $keyword, PDO::PARAM_STR);
$query2->execute();
$list2 = $query2->fetchAll();
foreach ($list2 as $rs2) {
	// put in bold the written text
	$Mcompuesto = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'</b>', $rs2['Compuesto']);
	// add new option
	echo '<li onclick="set_item(\''.str_replace("'", "\'", $rs2['Compuesto']).'\')">'.$Mcompuesto.'</li>';
}

$sql3 = "SELECT * FROM Medicamento WHERE Marca LIKE (:keyword) ORDER BY Marca ASC LIMIT 0, 10";
$query3 = $pdo->prepare($sql3);
$query3->bindParam(':keyword', $keyword, PDO::PARAM_STR);
$query3->execute();
$list3 = $query3->fetchAll();
foreach ($list3 as $rs3) {
	// put in bold the written text
	$Mmarca = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'</b>', $rs3['Nombre']);
	// add new option
	echo '<li onclick="set_item(\''.str_replace("'", "\'", $rs3['Nombre']).'\')">'.$Mmarca.'</li>';
}
?>