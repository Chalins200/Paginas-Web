// autocomplet : this function will be executed every time we change the text
function autocomplet() {
	var min_length = 1; // min caracters to display the autocomplete
	var keyword = $('#keyword').val();
	if (keyword.length >= min_length) {
		$.ajax({
			url: 'Refresh.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#list_id').show();
				$('#list_id').html(data);
			}
		});
	} else {
		$('#list_id').hide();
	}
}

// set_item : this function will be executed when we select an item
function set_item(item) {
	// change input value
	$('#keyword').val(item);
	// hide proposition list
	$('#list_id').hide();
}