<?php include ('conexion.php');

$paciente=$_GET['paciente'];
$consultorio=$_GET['consultorio'];
$fecha=$_GET['fecha'];
$hora=$_GET['hora'];
$doctor=$_GET['doctor'];

$sen="INSERT INTO  Citas (Id_cita, Id_paciente, Id_consultorio, Fecha,
Hora, Estado, Id_doctor)
VALUES (
'',
$paciente,
'$consultorio',
'$fecha',
'$hora',
'Pendiente',
'$doctor');";

mysql_query($sen);

echo $sen;

 ?>