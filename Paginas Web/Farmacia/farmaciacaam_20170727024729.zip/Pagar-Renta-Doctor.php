<?php
include("conexion.php");
$fecha=date("Y-m-d");
session_start();
?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8 with BOM">
  <title>pAGO DE RENTA</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="css/style.css">

  
</head>



<body>

<!-- Navbar -->
<div class="w3-top">
<ul class="w3-navbar w3-black w3-card-2 w3-left-align">  
     <li class="w3-hide-small w3-dropdown-hover">
    <a href="Doctor.php" class="w3-hover-none w3-padding-large" title="More">Inicio</a>   
  </li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Citas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="registrarCitaF.php">Agendar cita</a>
      <a href="cobrarCitaF.php">Mostrar citas</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Medicamentos <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="#">Vender Medicamento</a>
      <a href="Consultar-Medicamento.php">Medicamentos por nombre</a>
      <a href="Consultar-Medicamento-Compuesto.php">Medicamentos por compuesto</a>
      <a href="Consultar-Medicamento-Marca.php">Medicamentos por marca</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Pacientes <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Paciente.php">Registrar paciente</a>
      <a href="Consultar-Paciente.php">Mostrar pacientes</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Entradas/Salidas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Consultar-Entradas-Doctor.php">Mostrar Entradas</a>
      <a href="Consultar-Salidas-Doctor.php">Mostrar Salidas</a>
      <a href="Pagar-Renta-Doctor.php">Pagar Renta</a>
     </div>
</li>

 <li class="w3-hide-small w3-dropdown-hover">
    <a href="cerrarsesion.php" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesi�n</a>
  </li>
</ul>
</div>

<body>
  
<!-- Mixins-->
<!-- Pen Title-->

<table>
<tr>

</tr>
</table>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Registro de habitaciones</h1>
    <form method="POST" action="Pagar-Renta-Doctor.php">
      <div class="input-container">
        ID Consultorio:
        <div class="bar"></div>
        <select id="tipo" name="consultorio" required="required">
	<?php
       		$sen="Select * from Consultorio WHERE Id_usuario='{$_SESSION['id_usuario']}'";
       		$Rsen=mysql_query($sen);
       		while($p=mysql_fetch_array($Rsen)){
       			echo "<option value={$p['Id_consultorio']}>{$p['Id_consultorio']}</option>";
       		}
       	?>
	</select>
	<input type="hidden" name="detalle" value="Renta de consultorio"/>
	<input type="hidden" name="departamento" value="Doctores"/>
      </div>      
      
  	<div class="input-container">
  	Costo del consultorio ($):
        <div class="bar"></div>
  	<select id="tipo" name="costo" required="required">
	<?php
       		$sen="Select * from Consultorio WHERE Id_usuario='{$_SESSION['id_usuario']}'";
       		$Rsen=mysql_query($sen);
       		while($p=mysql_fetch_array($Rsen)){
       			echo "<option value={$p['Costo']}>{$p['Costo']}</option>";
       		}
       	?>
	</select>
        
      </div>
     
  
      <br>
      <br>
  
      <div class="button-container">
        <button><span>Pagar</span></button>
      </div>
      
    </form>
    
</body>
</html>

<?php
if($_POST['consultorio'] == null){

}else{
$salidasd= "INSERT INTO SalidasDoctor VALUES ('','{$_POST['detalle']}','$fecha','{$_SESSION['id_usuario']}',{$_POST['costo']})";
$r1=mysql_query($salidasd);
$clinica= "INSERT INTO EntradasClinica VALUES ('','{$_POST['departamento']}','$fecha',{$_POST['costo']})";
$r2=mysql_query($clinica);
$detalle= "INSERT INTO DetalleRenta VALUES ('','{$_POST['consultorio']}','{$_SESSION['id_usuario']}',{$_POST['costo']})";
$r3=mysql_query($detalle);
echo "<center> El PAGO SE REALIZ� CON EXITO </center>";

}
?>