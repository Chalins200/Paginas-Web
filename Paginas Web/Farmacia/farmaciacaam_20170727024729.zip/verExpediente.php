<?php
header("location: http://farmaciacaam.webcindario.com/expedientes/{$_POST['paciente']}.txt");
?>