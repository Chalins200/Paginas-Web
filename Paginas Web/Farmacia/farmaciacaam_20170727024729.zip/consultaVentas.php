<?php
include("conexion.php");
?>

<!DOCTYPE html>

<head>
  <meta charset="UTF-8 with BOM">
  <title>Consultar ventas</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
   
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="css/style.css">

</head>

<body>

<!-- Navbar -->
<div class="w3-top">
<ul class="w3-navbar w3-black w3-card-2 w3-left-align">
    <li class="w3-hide-small w3-dropdown-hover">
    <a href="Doctor.php" class="w3-hover-none w3-padding-large" title="More">Inicio</a>   
  </li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Citas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="registrarCitaF.php">Agendar cita</a>
      <a href="cobrarCitaF.php?doctor=<?php session_start();?><?php  echo $_SESSION['id_usuario'];  ?>">Mostrar citas</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Medicamentos <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="#">Vender Medicamento</a>
      <a href="Consultar-Medicamento.php">Medicamentos por nombre</a>
      <a href="Consultar-Medicamento-Compuesto.php">Medicamentos por compuesto</a>
      <a href="Consultar-Medicamento-Marca.php">Medicamentos por marca</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Pacientes <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Registrar-Paciente.php">Registrar paciente</a>
      <a href="Consultar-Paciente.php">Mostrar pacientes</a>
     </div>
</li>

<li class="w3-hide-small w3-dropdown-hover">
    <a href="javascript:void(0)" class="w3-hover-none w3-padding-large" title="More">Entradas/Salidas <i class="fa fa-caret-down"></i></a>
    <div class="w3-dropdown-content w3-white w3-card-4">
      <a href="Consultar-Entradas-Doctor.php">Mostrar Entradas</a>
      <a href="Consultar-Salidas-Doctor.php">Mostrar Salidas</a>
      <a href="Pagar-Renta-Doctor.php">Pagar Renta</a>
     </div>
</li>

 <li class="w3-hide-small w3-dropdown-hover">
    <a href="cerrarsesion.php" class="w3-hover-none w3-padding-large" title="More">Cerrar Sesi�n</a>
  </li>
</ul>
</ul>
</div>

<body>
  <br><br><br>
  <div class="card">
    <h1 class="title">Ventas Clinica</h1>
        <div class="bar"></div>
        <div class="input-container">
        <center>
  
  <form action=consultaVentas.php method=POST>
 Fecha de inicio: <input type=date name=fechaInicial>
  Fecha de fin: <input type=date name=fechaFinal>
  <input type=submit name=btnPeriodo value='Buscar en periodo' style='width:15%; border: 1px solid black; background-color: red;'><br><br>
  </form>
  
<table style="width:70%; border: 1px solid black; border-collapse: collapse; padding:25px;">
    <tr>
    <td style="background-color: black; color: white;" align=center>Id Compra</td>
    <td style="background-color: black; color: white;" align=center>Departamento</td>
    <td style="background-color: black; color: white;" align=center>Fecha</td>
    <td style="background-color: black; color: white;" align=center>Total</td>
    <td style="background-color: black; color: white;" align=center>Detalle</td>
 
    </tr>
    
 <?php
 $totales=0;
 
 if($_POST['fechaInicial']){
  $totales=0;
    $sql3= "select * from EntradasClinica where Fecha  between '{$_POST['fechaInicial']}' AND '{$_POST['fechaFinal']}'";
    //echo $sql3."<br>";
    $r3=mysql_query($sql3,$c);
 	while($arr2=mysql_fetch_array($r3))
      {
      echo "<form action=verDetalleVenta.php method=POST>
      <input type=hidden name=venta value={$arr2['Id_entrada']}>
       <input type=hidden name=total value={$arr2['Total']}>
      <tr><td align=center>{$arr2['Id_entrada']}</td>
      <td align=center>{$arr2['Departamento']}</td>
      <td align=center>{$arr2['Fecha']}</td>
      <td align=center>{$arr2['Total']}</td>
     
      <td align=center><input type=submit name=btnExpediente value='Ver Detalle' style='width:80%; border: 1px solid black; background-color: green;'></td></tr>
      </form>";
       $totales+=$arr2['Total'];
      }
 }else{
  $totales=0;
    $sql= "select * from EntradasClinica";
    $r2=mysql_query($sql,$c);
      while($arr2=mysql_fetch_array($r2))
      {
      echo "<form action=verDetalleVenta.php method=POST>
      <input type=hidden name=venta value={$arr2['Id_entrada']}>
       <input type=hidden name=total value={$arr2['Total']}>
      <tr><td align=center>{$arr2['Id_entrada']}</td>
      <td align=center>{$arr2['Departamento']}</td>
      <td align=center>{$arr2['Fecha']}</td>
      <td align=center>{$arr2['Total']}</td>
     
      <td align=center><input type=submit name=btnExpediente value='Ver Detalle' style='width:80%; border: 1px solid black; background-color: green;'></td></tr>
      </form>";
       $totales+=$arr2['Total'];
      }
      }
    echo "</select><br>";
//echo "Los totales son:{$totales}";
  echo "</div>";

  ?>
  </table>
  
  <?php
  $entradas=0;
  $salidas=0;
  
  $sql4= "select * from EntradasClinica where Fecha  between '{$_POST['fechaInicial']}' AND '{$_POST['fechaFinal']}'";
    //echo $sql3."<br>";
    $r4=mysql_query($sql4,$c);
 	while($arr4=mysql_fetch_array($r4))
      {
     // echo $arr4['Total'];
      	$entradas+=$arr4['Total'];
      }
      
   $sql5= "select * from SalidasClinica where Fecha  between '{$_POST['fechaInicial']}' AND '{$_POST['fechaFinal']}'";
    //echo $sql3."<br>";
    $r5=mysql_query($sql5,$c);
 	while($arr5=mysql_fetch_array($r5))
      {
     // echo $arr5['Total'];
      	$salidas+=$arr5['Total'];
      }
      
     // echo $sql4."<br>";
      //echo $sql5."<br>";
      echo "<br><br><br><font size=6>";
      $utilidad;
      echo "Dinero en ventas: $".$entradas." , gasto en compras: $".$salidas."<br>";
      $utilidad=$entradas-$salidas;
      echo "<h1>La utilidad en el periodo seleccionado es de: $".$utilidad."</h1>";
      echo "</font>";
  ?>
  
  </center>
  </div>
</body>
</html>