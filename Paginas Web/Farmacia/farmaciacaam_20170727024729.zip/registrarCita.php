<?php include("conexion.php");

session_start();
$Sentencia="insert into Citas (Id_cita,Id_paciente,Id_consultorio,Fecha,Hora,Estado,Id_doctor) 
values('','{$_POST['paciente']}','{$_POST['consultorio']}','{$_POST['fecha']}','{$_POST['hora']}','pendiente','{$_SESSION['id_usuario']}')";


mysql_query($Sentencia); 

echo $Sentencia;

header("location: cobrarCitaF.php?doctor={$_SESSION['id_usuario']}");

?>