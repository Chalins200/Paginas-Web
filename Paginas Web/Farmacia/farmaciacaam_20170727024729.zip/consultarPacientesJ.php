<?php
include('funcionesJ.php');

if($resultset=getSQLResultSet("SELECT * FROM Pacientes")){
	while ($row = $resultset->fetch_array(MYSQLI_NUM)){
		echo json_encode($row);
	}
}

?>