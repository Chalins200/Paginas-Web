<?php

echo "<center><h1>Registro Guardado con Exito</h1></center>";

?>