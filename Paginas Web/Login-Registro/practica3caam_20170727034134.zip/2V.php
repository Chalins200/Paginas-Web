<?php

$c=mysql_connect("mysql.webcindario.com","practica3caam","chalin123456");
mysql_select_db("practica3caam",$c);
$sql="select * from Tabla1 where Usuario='{$_POST['user1']}' and Clave='{$_POST['pass1']}'";
$r=mysql_query($sql,$c);

if($arr=mysql_fetch_array($r)){

echo "Priviligios: {$arr['Tipo']}"."<br><br>" ;
	if(strcmp($arr['Tipo'],"Gerente")== 0){
	echo "Bienvenido ".$arr['Nombre']."<br><br>" ;
	echo "<form action=3V.php method=POST>";	
	echo "Persona: <input type=text name=per1><br><br>";
	echo "Calle: <input type=text name=call1><br><br>";
	echo "CP: <input type=text name=cp1><br><br>";
	echo "Poblacion: <input type=text name=pob1><br><br>";
	echo "Estado: <input type=text name=est1><br><br>";
	echo "<input type=submit value=Guardar></form>";

	}else if(strcmp($arr['Tipo'],"Secretario")== 0)
	{
	echo "Bienvenido ".$arr['Nombre']."<br><br>" ;
	echo "<h3>Es Secretario</h3>" ;
	
	$sqll="select * from Tabla2";
	$rr=mysql_query($sqll,$c);
	echo "<table border=1><tr><td>Persona</td><td>Calle</td><td>Codigo Postal</td><td>Poblacion</td><td>Estado</td></tr>";

      while ($aarr=mysql_fetch_array($rr))
      {
	echo"<tr>";      
	 echo "<td>{$aarr['Persona']}</td>";
	 echo "<td>{$aarr['Calle']}</td>";
	 echo "<td>{$aarr['CP']}</td>";
	 echo "<td>{$aarr['Poblacion']}</td>";
	 echo "<td>{$aarr['Estado']}</td></tr></table>";
      }
      
	}
	else if(strcmp($arr['Tipo'],"Secretaria")== 0)
	{
	echo "Bienvenido ".$arr['Nombre']."<br><br>" ;
	echo "<h3>Es Secretaria</h3>" ;
	$sqll="select * from Tabla2";
	$rr=mysql_query($sqll,$c);
	echo "<table border=1><tr><td>Persona</td><td>Calle</td><td>Codigo Postal</td><td>Poblacion</td><td>Estado</td></tr>";

      while ($aarr=mysql_fetch_array($rr))
      {
	echo"<tr>";      
	 echo "<td>{$aarr['Persona']}</td>";
	 echo "<td>{$aarr['Calle']}</td>";
	 echo "<td>{$aarr['CP']}</td>";
	 echo "<td>{$aarr['Poblacion']}</td>";
	 echo "<td>{$aarr['Estado']}</td></tr></table>";
      }
	
	}
	else if(strcmp($arr['Tipo'],"Empleado")== 0)
	{
	echo "Bienvenido ".$arr['Nombre']."<br><br>" ;
	echo "<h3>Es Empleado</h3>" ;
	}
	else 
	{
	echo "Usuario no valido";
	//echo "<h3>No tienes los privilegios necesarios para observar la informaci�n</h3>" ;
	}

}else{
echo "<h3>Necesitas Iniciar Sesi�n<h3>" ;
echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=1V.php'><body>Espera, te vamos a redireccionar... </body></html>";
		

}?>