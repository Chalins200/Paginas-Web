<?php

echo "<form action=2V.php method=POST>";

echo "Usuario: <input type=text name=user1><br><br>";
echo "Contrase�a:<input type=password name=pass1><br><br>";

echo "<input type=submit value=ir></form>";
?>
