<?php
include("conexion.php");
session_start();
$sql="SELECT * FROM arbitro WHERE Nombre='{$_POST['id']}' and Contrase�a='{$_POST['clave']}'";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);


if (strcmp($arr['Encargado'],"1")== 0) {
	$_SESSION['Tipo'] = "Encargado";
	header("Location:arbitro.php");
	echo "Encargado<br>";
}else if (strcmp($arr['Encargado'],"0")== 0){
	$_SESSION['Tipo'] = "Arbitro";
	$_SESSION['ID'] = $arr['IDArbitro'];
	header("Location:arbitro.php");
	echo "Arbitro<br>";
}else{
	$_SESSION['Tipo'] = "Jugador";
header("Location:index.html");
	echo "NO entro<br>";
}
 echo $sql;
?>