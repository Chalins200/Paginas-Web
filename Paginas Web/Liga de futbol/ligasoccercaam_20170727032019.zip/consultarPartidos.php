<?php
include("conexion.php");
session_start();


echo "
<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Prologue by HTML5 UP</title>
		<meta charset='utf-8' />
		<meta name='viewport' content='width=device-width, initial-scale=1' />
		<!--[if lte IE 8]><script src='assets/js/ie/html5shiv.js'></script><![endif]-->
		<link rel='stylesheet' href='assets/css/main.css' />
		<!--[if lte IE 8]><link rel='stylesheet' href='assets/css/ie8.css' /><![endif]-->
		<!--[if lte IE 9]><link rel='stylesheet' href='assets/css/ie9.css' /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<div id='header'>

				<div class='top'>

					<!-- Logo -->
						<div id='logo'>
							<span class='image avatar48'><img src='images/avatar.png' alt='' /></span>
							<h1 id='title'>Liguilla</h1>
							<p>Apertura 2016</p>
						</div>

					<!-- Nav -->
						<nav id='nav'>
							<!--

								Prologue's nav expects links in one of two formats:

								1. Hash link (scrolls to a different section within the page)

								   <li><a href='#foobar' id='foobar-link' class='icon fa-whatever-icon-you-want skel-layers-ignoreHref'><span class='label'>Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href='http://foobar.tld' id='foobar-link' class='icon fa-whatever-icon-you-want'><span class='label'>Foobar</span></a></li>

							-->";
							if($_SESSION['Tipo']=="Encargado") {
								echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Encargado</span></a></li>
								<li><a href='agregarEquipo.html' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Equipos</span></a></li>
								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>
								<li><a href='agregarPartido.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Partidos</span></a></li>
								<li><a href='AltaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Jugadores</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='registrarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Arbitros</span></a></li>
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>
								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Arbitro") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Arbitro</span></a></li>

								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>

								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='consultaResultados.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Enviar Resultados</span></a></li>
								
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>

								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Jugador") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>General</span></a></li>
						
						<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Partidos</span></a></li>
						<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Equipos</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Jugadores</span></a></li>
												
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Arbitros</span></a></li></ul>

								<form action='login.php' method='POST' enctype='multipart/form-data'>
								<div class='row'>
									<div align=center>
									Iniciar Sesi�n
									<input class='login' type='text' name='id' placeholder='ID' /></div>
									<div>
									<input class='login' type='password' name='clave' placeholder='Contrase�a' /></div>
								
									<div align=center>
									<center><input class='loginB' align='rigth' type='submit' value='Iniciar' /></center>
									</div>
								</div>
							</form>";
							}
							
							
					echo"		
						</nav>

				</div>
				</div>

		<!-- Main -->
			<div id='main'>

				

				
				<!-- Portfolio -->
					<section id='about' class='two'>
						<div class='container'>

							<header>
								<h2>Roles de Partidos</h2>
							</header>

							<p>Aqui encontraras toda la informacion de los partidos habidos y por haber!.</p>
							
							<div class='row'>";
							
							$Sen="select * from partidos";
							$r=mysql_query($Sen);
							while($partido=mysql_fetch_array($r)){
								//Consulta de los nombres de equipos a enfrentar
								$id=$partido['IDPartido'];
								$local=mysql_query("select Nombre from equipos where IDEquipo={$partido['IDEquipoLocal']};");
								$visitante=mysql_query("select Nombre from equipos where IDEquipo={$partido['IDEquipoVisitante']};");
								
								$v1=mysql_fetch_array($local);
								$v2=mysql_fetch_array($visitante);
								
								echo"
							
								<div class='4u 12u(mobile)'>
									<article class='item'>
										<a href='detallePartido.php?id=$id' class='image fit'><img src='images/pic02.jpg' alt='' /></a>
										<header>";
										$estado=$partido['Estado'];
											if($estado=='Empatado'){
												echo "<font color=red>Empatado</font>";
											}else if($estado=='Pendiente'){
												echo "<font color=red>{$partido['Fecha']} a las {$partido['Hora']}</font>";
											}
											else if($estado=='Jugado'){
												echo "<font color=red>Jugado</font>";
											}
										echo"	<h2>{$v1['Nombre']}</h2><h3>VS</h3><h2> {$v2['Nombre']}</h2>
										</header>
										
									</article>
									
									
								</div>
								
							";
							}

					echo"</div>	</div>
					</section>

			</div>

		<!-- Footer -->
			<div id='footer'>

				<!-- Copyright -->
					<ul class='copyright'>
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href='http://html5up.net'>HTML5 UP</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src='assets/js/jquery.min.js'></script>
			<script src='assets/js/jquery.scrolly.min.js'></script>
			<script src='assets/js/jquery.scrollzer.min.js'></script>
			<script src='assets/js/skel.min.js'></script>
			<script src='assets/js/util.js'></script>
			<!--[if lte IE 8]><script src='assets/js/ie/respond.min.js'></script><![endif]-->
			<script src='assets/js/main.js'></script>

	</body>
</html>";

?>