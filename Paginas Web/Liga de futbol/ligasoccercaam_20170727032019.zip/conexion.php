<?php
$c= mysql_connect('mysql.webcindario.com','ligasoccercaam','ligacaam');
mysql_select_db('ligasoccercaam',$c);
?>