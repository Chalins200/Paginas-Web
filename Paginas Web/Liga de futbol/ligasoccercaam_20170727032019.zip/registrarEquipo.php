<?php include('conexion.php');

$sen=mysql_query("select count(*) from equipos;");
$r=mysql_fetch_array($sen);
$num=$r['count(*)']+1;

$Sentencia="insert into equipos(IDEquipo,Nombre,IDCancha,Escudo) 
values ('','{$_POST['nombre']}',$num,'{$_POST['escudo']}');";

$Sentencia2="insert into cancha (IDCancha,Nombre,IDEquipo,Lugar,Foto) 
values ('','{$_POST['cancha']}',$num,'{$_POST['lugar']}','{$_POST['foto']}');";

mysql_query($Sentencia);
mysql_query($Sentencia2);

echo $Sentencia1."<br>";
echo $Sentencia2;

header("location: consultarEquipos.php")


?>