<?php include('conexion.php');
//Datos del Partido
$idPartido=$_GET['id'];
$Sen="select * from partidos where IDPartido=$idPartido;";
$r=mysql_query($Sen);
$partido=mysql_fetch_array($r);

//Datos de la Cancha
$r0=mysql_query("select * from cancha where IDEquipo={$partido['IDCancha']}");
$cancha=mysql_fetch_array($r0);

//Datos de Extras
//Arbitro
$r1=mysql_query("Select * from arbitro where IDArbitro={$partido['IDArbitro']};");
$arbitro=mysql_fetch_array($r1);
//Equipo Local
$r2=mysql_query("Select * from equipos where IDEquipo={$partido['IDEquipoLocal']};");
$local=mysql_fetch_array($r2);
//Equipo Visitante
$r3=mysql_query("Select * from equipos where IDEquipo={$partido['IDEquipoVisitante']};");
$visitante=mysql_fetch_array($r3);
echo"

<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Detalle de Partidos</title>
		<meta charset='utf-8 with BOM' />
		<meta name='viewport' content='width=device-width, initial-scale=1' />
		<!--[if lte IE 8]><script src='assets/js/ie/html5shiv.js'></script><![endif]-->
		<link rel='stylesheet' href='assets/css/main.css' />
		<!--[if lte IE 8]><link rel='stylesheet' href='assets/css/ie8.css' /><![endif]-->
		<!--[if lte IE 9]><link rel='stylesheet' href='assets/css/ie9.css' /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<div id='header'>

				<div class='top'>

					<!-- Logo -->
						<div id='logo'>
							<span class='image avatar48'><img src='images/avatar.jpg' alt='' /></span>
							<h1 id='title'>Liga Piyoto</h1>
							<p>Super Campeones!</p>
						</div>

					<!-- Nav -->
						<nav id='nav'>
							<!--

								Prologue's nav expects links in one of two formats:

								1. Hash link (scrolls to a different section within the page)

								   <li><a href='#foobar' id='foobar-link' class='icon fa-whatever-icon-you-want skel-layers-ignoreHref'><span class='label'>Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href='http://foobar.tld' id='foobar-link' class='icon fa-whatever-icon-you-want'><span class='label'>Foobar</span></a></li>

							-->
							<ul>
								<li><a href='#top' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Inicio</span></a></li>
								
								<li><a href='consultarPartidos.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Partidos</span></a></li>
								
								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Equipos</span></a></li>
								
								<li><a href='#' id='contact-link' class='skel-layers-ignoreHref'><span class='icon fa-envelope'>Goles</span></a></li>
							</ul>
						</nav>

				</div>

			</div>

		<!-- Main -->
			<div id='main'>

				

				
				<!-- Portfolio -->
					<section id='about' class='two'>
						<div class='container'>

						<p>Los datos del partido estan actualizados para que estes al tanto de todas las novedades de tus partidos favoritos.</p>
						
							<header>
								<font color=blue size=20px>{$local['Nombre']}</font>
<font color=red size=5px> VS</font> <font color=blue size=20px>{$visitante['Nombre']}</font><br>
							</header>
							
							<div class='row'>
								<div class='12u$'>
									<article class='item'>
										<table ><th><img src='images/pic02.jpg' alt='' /></th><th><img src='images/pic02.jpg' alt='' /></th></table>
				
									<header>
									


			</header>
										
										
									</article>
								
					
						<h2>Informaci&oacute;n</h2>
					<form action=enviarGoles.php method=POST>	
<hr><h3>Gandador</h3>
<select name=ganador><option >{$visitante['Nombre']}</option><option>{$local['Nombre']}</option></select> <br>
<h3>Goles:</h3><input type='number' name='golesG' min=0 max=50>
<hr>

<hr><h3>Perdedor</h3>
<select name=perdedor><option >{$visitante['Nombre']}</option><option>{$local['Nombre']}</option></select> <br>
<h3>Goles:</h3><input type='number' name='golesP' min=0 max=50>
<hr>
<input type=hidden value={$_GET['id']} name=id>
<input type=submit name=btn value=Continuar>
</form>";

				
				echo "					
								</div>
								
								
							

					</div></div>
					</section>

			</div>

		<!-- Footer -->
			<div id='footer'>

				<!-- Copyright -->
					<ul class='copyright'>
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href='http://html5up.net'>HTML5 UP</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src='assets/js/jquery.min.js'></script>
			<script src='assets/js/jquery.scrolly.min.js'></script>
			<script src='assets/js/jquery.scrollzer.min.js'></script>
			<script src='assets/js/skel.min.js'></script>
			<script src='assets/js/util.js'></script>
			<!--[if lte IE 8]><script src='assets/js/ie/respond.min.js'></script><![endif]-->
			<script src='assets/js/main.js'></script>

	</body>
</html>";

?>