<?php include('conexion.php');
session_start();
echo"

<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Equipos Inscritos</title>
		<meta charset='utf-8 with BOM' />
		<meta name='viewport' content='width=device-width, initial-scale=1' />
		<!--[if lte IE 8]><script src='assets/js/ie/html5shiv.js'></script><![endif]-->
		<link rel='stylesheet' href='assets/css/main.css' />
		<!--[if lte IE 8]><link rel='stylesheet' href='assets/css/ie8.css' /><![endif]-->
		<!--[if lte IE 9]><link rel='stylesheet' href='assets/css/ie9.css' /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<div id='header'>

				<div class='top'>

					<!-- Logo -->
						<div id='logo'>
							<span class='image avatar48'><img src='images/avatar.jpg' alt='' /></span>
							<h1 id='title'>Liga Piyoto</h1>
							<p>Super Campeones!</p>
						</div>

					<!-- Nav -->
						<nav id='nav'>
							<!--

								Prologue's nav expects links in one of two formats:

								1. Hash link (scrolls to a different section within the page)

								   <li><a href='#foobar' id='foobar-link' class='icon fa-whatever-icon-you-want skel-layers-ignoreHref'><span class='label'>Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href='http://foobar.tld' id='foobar-link' class='icon fa-whatever-icon-you-want'><span class='label'>Foobar</span></a></li>

							-->";
							if($_SESSION['Tipo']=="Encargado") {
								echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Encargado</span></a></li>
								<li><a href='agregarEquipo.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Equipos</span></a></li>
								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>
								<li><a href='agregarPartido.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Partidos</span></a></li>
								<li><a href='AltaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Jugadores</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='registrarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Arbitros</span></a></li>
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>
								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Arbitro") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Arbitro</span></a></li>

								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>

								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='consultaResultados.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Enviar Resultados</span></a></li>
								
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>

								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Jugador" || $_SESSION['Tipo']=="") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>General</span></a></li>
						
						<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Partidos</span></a></li>
						<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Equipos</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Jugadores</span></a></li>
												
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Arbitros</span></a></li></ul>

								<form action='login.php' method='POST' enctype='multipart/form-data'>
								<div class='row'>
									<div align=center>
									Iniciar Sesi�n
									<input class='login' type='text' name='id' placeholder='ID' /></div>
									<div>
									<input class='login' type='password' name='clave' placeholder='Contrase�a' /></div>
								
									<div align=center>
									<center><input class='loginB' align='rigth' type='submit' value='Iniciar' /></center>
									</div>
								</div>
							</form>";
							}
							
							
					echo"
						</nav>

				</div>

			</div>

		<!-- Main -->
			<div id='main'>

				

				
				<!-- Portfolio -->
					<section id='about' class='two'>
						<div class='container'>

							<header>
								<h2>Equipos Inscritos {$_SESSION['Tipo']}</h2>
							</header>

							<p>Estos son los equipos participantes en la liga, todos los cambios y avisos seran publicados en esta plataforma.</p>
							
							<div class='row'>";
							
							$Sen="select * from equipos";
							$r=mysql_query($Sen);
							while($equipo=mysql_fetch_array($r)){
								$id=$equipo['IDEquipo'];
								echo"
							
								<div class='4u 12u$(mobile)'>
									<article class='item'>
										<a href='detalleEquipo.php?id=$id' class='image fit'><img src='images/pic02.jpg' alt='' /></a>
										<header>
											<h3>{$equipo['Nombre']}</h3>
										</header>
										
									</article>
									
									
								</div>
								
							";
							}

					echo"</div>	</div>
					</section>

			</div>

		<!-- Footer -->
			<div id='footer'>

				<!-- Copyright -->
					<ul class='copyright'>
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href='http://html5up.net'>HTML5 UP</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src='assets/js/jquery.min.js'></script>
			<script src='assets/js/jquery.scrolly.min.js'></script>
			<script src='assets/js/jquery.scrollzer.min.js'></script>
			<script src='assets/js/skel.min.js'></script>
			<script src='assets/js/util.js'></script>
			<!--[if lte IE 8]><script src='assets/js/ie/respond.min.js'></script><![endif]-->
			<script src='assets/js/main.js'></script>

	</body>
</html>";

?>