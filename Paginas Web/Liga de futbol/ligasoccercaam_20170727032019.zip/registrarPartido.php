<?php include('conexion.php');

$se="select * from cancha where IDEquipo='{$_POST['local']}'";
$r=mysql_query($se);
$cancha=mysql_fetch_array($r);
$id=$cancha['IDCancha'];
echo $se;
echo $id;

$Sentencia="insert into partidos(IDPartido,IDArbitro,IDCancha,IDEquipoLocal,IDEquipoVisitante,Estado,Fecha,Hora) values ('',{$_POST['arbitro']},$id,{$_POST['local']},{$_POST['visitante']},'Pendiente','{$_POST['fecha']}','{$_POST['hora']}');";


mysql_query($Sentencia);
//mysql_query($Sentencia2);
echo "<br>".$Sentencia;
header("location: consultarPartidos.php")


?>