<?php

$dsn = 'mysql:dbname=ligasoccercaam;host=mysql.webcindario.com';
$user = 'ligasoccercaam';
$password = 'ligacaam';

try{

	$pdo = new PDO(	$dsn, 
					$user,
					$password
					);
	

}catch( PDOException $e ){
	echo 'Error al conectar: ' . $e->getMessage();
}

?>