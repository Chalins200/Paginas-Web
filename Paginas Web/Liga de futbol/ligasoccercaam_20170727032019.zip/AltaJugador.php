<pre><?php
require_once('Gconexion.php');
$sql="SELECT * FROM equipos";
$statement = $pdo->prepare($sql);
$statement->execute();    
$results = $statement->fetchAll();

?>
</pre>

<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Match Soccer</title>
		<meta charset="utf-8 with BOM" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<div id="header">

				<div class="top">

					<!-- Logo -->
						<div id="logo">
							<span class="image avatar48"><img src="images/avatar.jpg" alt="" /></span>
							<h1 id="title">Jane Doe</h1>
							<p>Hyperspace Engineer</p>
						</div>

					<!-- Nav -->
						<nav id="nav">
						<?php
						session_Start();
						
								if($_SESSION['Tipo']=="Encargado") {
								echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Encargado</span></a></li>
								<li><a href='agregarEquipo.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Equipos</span></a></li>
								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>
								<li><a href='agregarPartido.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Partidos</span></a></li>
								<li><a href='AltaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Jugadores</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='registrarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Arbitros</span></a></li>
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>
								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Arbitro") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Arbitro</span></a></li>

								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>

								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='consultaResultados.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Enviar Resultados</span></a></li>
								
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>

								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Jugador") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>General</span></a></li>
						
						<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Partidos</span></a></li>
						<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Equipos</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Jugadores</span></a></li>
												
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Arbitros</span></a></li></ul>

								<form action='login.php' method='POST' enctype='multipart/form-data'>
								<div class='row'>
									<div align=center>
									Iniciar Sesi�n
									<input class='login' type='text' name='id' placeholder='ID' /></div>
									<div>
									<input class='login' type='password' name='clave' placeholder='Contrase�a' /></div>
								
									<div align=center>
									<center><input class='loginB' align='rigth' type='submit' value='Iniciar' /></center>
									</div>
								</div>
							</form>";
							}

							?>
						</nav>

				</div>

				<div class="bottom">

					<!-- Social Icons -->
						<ul class="icons">
							<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
							<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
						</ul>

				</div>

			</div>

		<!-- Main -->
			<div id="main">

				<!-- Intro -->
					<section id="top" class="one dark cover">
						<div class="container">

							<header>
								<h2 class="alt">Registro de Jugadores!!</h2>
								</br></br>
								<p>Registra a los nuevos jugadores y enlazalos con sus equipos </br>
								<b>!</b>no olvides llenar todos los  campos<b>�</b></p>
							</header>
							
							</br></br>
							<footer>
								<a href="#contact" class="button scrolly">Lo tengo</a>
							</footer>

						</div>
					</section>

				
				<!-- Contact -->
					<section id="contact" class="four">
						<div class="container">

							<header>
								<h2>Registro</h2>
							</header>

							<p>Elementum sem parturient nulla quam placerat viverra
							mauris non cum elit tempus ullamcorper dolor. Libero rutrum ut lacinia
							donec curae mus. Eleifend id porttitor ac ultricies lobortis sem nunc
							orci ridiculus faucibus a consectetur. Porttitor curae mauris urna mi dolor.</p>

							<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
								<div class="row">
									<div class="6u 12u$(mobile)"><input type="text" name="nombre" placeholder="Nombre" /></div>
									<div class="6u$ 12u$(mobile)"><input type="text" name="edad" placeholder="Edad" /></div>
									<div class="6u 12u$(mobile)">
									<select name="rol" placeholder="Rol" >
										<option value="" selected>Selecciona el rol del jugador</option>
										<option value="Arquero">Arquero</option>
										<option value="Defensa">Defensa</option>
										<option value="Lateral">Lateral</option>
										<option value="Centrocampista">Centrocampista</option>
										<option value="Delantero">Delantero</option>
										</select>
									</div>
									<div class="6u$ 12u$(mobile)">
										<select name="equipo" placeholder="Equipo" >
										<option value="" selected>Selecciona el equipo del jugador</option>
										<?php
   										 foreach($results as $rs)
   										 {   
  										?>
											<option value="<?php echo $rs['IDEquipo']?>"> <?php echo htmlentities($rs['Nombre']);?></option>
   									        <?php
 									         }
 									         ?>
										</select>							
									</div>
								
									<div class="12u$">
										<input type="submit" value="Guardar" />
									</div>
								</div>
							</form>

						</div>
					</section>

			</div>

		<!-- Footer -->
			<div id="footer">

				<!-- Copyright -->
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollzer.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>

<?php

if(isset($_POST['equipo']))

{
$nombre = $_POST['nombre'];
$edad = $_POST['edad'];
$rol = $_POST['rol'];
$equipo = $_POST['equipo'];

$sql1='INSERT INTO jugadores (IDJugador,Nombre,IDEquipo,Edad,Roll) VALUES(?,?,?,?,?)';
$statement1 = $pdo->prepare($sql1);
$statement1->execute(array('',$nombre,$equipo,$edad,$rol));

}
?>