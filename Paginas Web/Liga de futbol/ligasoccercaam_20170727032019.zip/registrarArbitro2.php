<?php
include("conexion.php");

$sql="INSERT INTO arbitro VALUES('','{$_POST['nombre']}','{$_POST['clave']}','0')";
$r=mysql_query($sql,$c);
if ($r) {
	//header("Location:correcto.html");
	header("Location:consultarArbitro.php");
}else{
	//header("Location:incorrecto.html");
}

?>