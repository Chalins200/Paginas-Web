<?php include('conexion.php');
//Datos de Equipo
$idEquipo=$_GET['id'];
$Sen="select * from equipos where IDEquipo=$idEquipo;";
$r=mysql_query($Sen);
$equipo=mysql_fetch_array($r);

//Datos de Cancha
$r0=mysql_query("select * from cancha where IDEquipo=$idEquipo");
$cancha=mysql_fetch_array($r0);

//Datos de Marcadores
//Jugados
$r1=mysql_query("Select count(*) from detallepartido where Ganador='{$equipo['Nombre']}' or Perdedor='{$equipo['Nombre']}';");
$jugados=mysql_fetch_array($r1);
//Ganados
$r2=mysql_query("Select count(*) from detallepartido where Ganador='{$equipo['Nombre']}';");
$ganados=mysql_fetch_array($r2);
//Perdidos
$r3=mysql_query("Select count(*) from detallepartido where Perdedor='{$equipo['Nombre']}';");
$perdidos=mysql_fetch_array($r3);
//Empatados
$r4=mysql_query("Select count(*) from partidos where IDEquipoLocal=$idEquipo and Estado='Empatado' or IDEquipoVisitante=$idEquipo and Estado='Empatado';");
$empatados=mysql_fetch_array($r4);
//Totales
$Tjugados=$jugados['count(*)']+$empatados['count(*)'];
echo"

<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Equipos Inscritos</title>
		<meta charset='utf-8 with BOM' />
		<meta name='viewport' content='width=device-width, initial-scale=1' />
		<!--[if lte IE 8]><script src='assets/js/ie/html5shiv.js'></script><![endif]-->
		<link rel='stylesheet' href='assets/css/main.css' />
		<!--[if lte IE 8]><link rel='stylesheet' href='assets/css/ie8.css' /><![endif]-->
		<!--[if lte IE 9]><link rel='stylesheet' href='assets/css/ie9.css' /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<div id='header'>

				<div class='top'>

					<!-- Logo -->
						<div id='logo'>
							<span class='image avatar48'><img src='images/avatar.jpg' alt='' /></span>
							<h1 id='title'>Liga Piyoto</h1>
							<p>Super Campeones!</p>
						</div>

					<!-- Nav -->
						<nav id='nav'>
							<!--

								Prologue's nav expects links in one of two formats:

								1. Hash link (scrolls to a different section within the page)

								   <li><a href='#foobar' id='foobar-link' class='icon fa-whatever-icon-you-want skel-layers-ignoreHref'><span class='label'>Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href='http://foobar.tld' id='foobar-link' class='icon fa-whatever-icon-you-want'><span class='label'>Foobar</span></a></li>

							-->
							<ul>
								<li><a href='#top' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Inicio</span></a></li>
								
								<li><a href='consultarPartidos.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Partidos</span></a></li>
								
								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Equipos</span></a></li>
								
								<li><a href='#' id='contact-link' class='skel-layers-ignoreHref'><span class='icon fa-envelope'>Goles</span></a></li>
							</ul>
						</nav>

				</div>

			</div>

		<!-- Main -->
			<div id='main'>

				

				
				<!-- Portfolio -->
					<section id='about' class='two'>
						<div class='container'>

						<p>Los datos del equipo estan actualizados para que estes al tanto de todas las novedades de tu equipo favorito.</p>
						
							<header>
								<h2>{$equipo['Nombre']}</h2>
							</header>
							
							<div class='row'>
								<div class='12u$'>
									<article class='item'>
										<center><img src='images/pic02.jpg' alt='' /></center>
										<header>
											<h2>Informaci&oacute;n</h2>
<hr><h3>Jugadores</h3><a href='ConsultaJugador.php'>Ver Jugadores</a><hr>					
<h3>Cancha: </h3> {$cancha['Nombre']} ({$cancha['Lugar']})<hr>
<h3>Partidos Jugados: </h3>$Tjugados<hr>
<h3>Partidos Ganados: </h3>{$ganados['count(*)']}<hr>
<h3>Partidos Perdidos: </h3>{$perdidos['count(*)']}<hr>
<h3>Partidos Empatados: </h3>{$empatados['count(*)']}<hr>
			</header>
										
										
									</article>
								
									
									
								</div>
								
								
							

					</div></div>
					</section>

			</div>

		<!-- Footer -->
			<div id='footer'>

				<!-- Copyright -->
					<ul class='copyright'>
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href='http://html5up.net'>HTML5 UP</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src='assets/js/jquery.min.js'></script>
			<script src='assets/js/jquery.scrolly.min.js'></script>
			<script src='assets/js/jquery.scrollzer.min.js'></script>
			<script src='assets/js/skel.min.js'></script>
			<script src='assets/js/util.js'></script>
			<!--[if lte IE 8]><script src='assets/js/ie/respond.min.js'></script><![endif]-->
			<script src='assets/js/main.js'></script>

	</body>
</html>";

?>