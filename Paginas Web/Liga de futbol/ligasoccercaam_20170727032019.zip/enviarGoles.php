<?php
include("conexion.php");

$Sen="insert into detallepartido (IDPartido,Ganador,Perdedor,GolesGanador,GolesPerdedor) 
values({$_POST['id']},'{$_POST['ganador']}','{$_POST['perdedor']}',{$_POST['golesG']},{$_POST['golesP']});";

echo $Sen;

$Sen2="update partidos set Estado='Jugado' where IDPartido={$_POST['id']}";

mysql_query($Sen);
mysql_query($Sen2);
header("location: consultarPartidos.php");
?>