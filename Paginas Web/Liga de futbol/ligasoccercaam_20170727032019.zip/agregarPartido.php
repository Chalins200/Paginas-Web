<?php include("conexion.php");
session_start();
echo"
<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Agregar Equipo</title>
		<meta charset='utf-8 with BOM' />
		<meta name='viewport' content='width=device-width, initial-scale=1' />
		<!--[if lte IE 8]><script src='assets/js/ie/html5shiv.js'></script><![endif]-->
		<link rel='stylesheet' href='assets/css/main.css' />
		<!--[if lte IE 8]><link rel='stylesheet' href='assets/css/ie8.css' /><![endif]-->
		<!--[if lte IE 9]><link rel='stylesheet' href='assets/css/ie9.css' /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<div id='header'>

				<div class='top'>

					<!-- Logo -->
						<div id='logo'>
							<span class='image avatar48'><img src='images/avatar.jpg' alt='' /></span>
							<h1 id='title'>Liga Piyoto</h1>
							<p>Super Campeones!</p>
						</div>

					<!-- Nav -->
						<nav id='nav'>
						";
							if($_SESSION['Tipo']=="Encargado") {
								echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Encargado</span></a></li>
								<li><a href='agregarEquipo.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Equipos</span></a></li>
								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>
								<li><a href='agregarPartido.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Registrar Partidos</span></a></li>
								<li><a href='AltaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Jugadores</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='registrarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Registrar Arbitros</span></a></li>
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>
								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Arbitro") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>Arbitro</span></a></li>

								<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consulta Partidos</span></a></li>

								<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Consultar Equipos</span></a></li>
								
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Jugadores</span></a></li>
								
								<li><a href='consultaResultados.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'>Enviar Resultados</span></a></li>
								
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Consultar Arbitros</span></a></li></ul>

								<li><a href='cerrarsesion.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'>Cerrar Sesion</span></a></li></ul>";
							}else if($_SESSION['Tipo']=="Jugador") {
	echo "<ul>
								<li><a href='#two' id='top-link' class='skel-layers-ignoreHref'><span class='icon fa-home'>General</span></a></li>
						
						<li><a href='consultarPartidos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Partidos</span></a></li>
						<li><a href='consultarEquipos.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-th'> Equipos</span></a></li>
								<li><a href='ConsultaJugador.php' id='portfolio-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Jugadores</span></a></li>
												
								<li><a href='consultarArbitro.php' id='about-link' class='skel-layers-ignoreHref'><span class='icon fa-user'> Arbitros</span></a></li></ul>

								<form action='login.php' method='POST' enctype='multipart/form-data'>
								<div class='row'>
									<div align=center>
									Iniciar Sesi�n
									<input class='login' type='text' name='id' placeholder='ID' /></div>
									<div>
									<input class='login' type='password' name='clave' placeholder='Contrase�a' /></div>
								
									<div align=center>
									<center><input class='loginB' align='rigth' type='submit' value='Iniciar' /></center>
									</div>
								</div>
							</form>";
							}
							
							
					echo"			
						</nav>

				</div>

			</div>

		<!-- Main -->
			<div id='main'>

				

				<!-- Contact -->
					<section id='contact' class='four'>
						<div class='container'>

							<header>
								<h2>Armar un Partido.</h2>
							</header>

							<!--<p>Elementum sem parturient nulla quam placerat viverra
							mauris non cum elit tempus ullamcorper dolor. Libero rutrum ut lacinia
							donec curae mus. Eleifend id porttitor ac ultricies lobortis sem nunc
							orci ridiculus faucibus a consectetur. Porttitor curae mauris urna mi dolor.</p> -->

							<form method='post' action='registrarPartido.php'>
								<div class='row'>
	
	
	<div class='6u 12u(mobile)'>
	<h5>Arbitro</h5>
	<select name=arbitro>";
		$r=mysql_query("select * from arbitro where Encargado=0");
		while($arbitro=mysql_fetch_array($r)){
			echo"<option value={$arbitro['IDArbitro']}>{$arbitro['Nombre']}</option>";
											}
		echo"</select>
	</div>
	
	<div class='6u 12u(mobile)'>
	<h5>Equipo Local</h5>
	<select name=local>";
		$r=mysql_query("select * from equipos");
		while($equipo=mysql_fetch_array($r)){
		
			echo"<option value={$equipo['IDEquipo']}>{$equipo['Nombre']}</option>";
											}
		echo"</select>
	</div>
	
	<div class='6u 12u(mobile)'>
	<h5>Equipo Visitante</h5>
	<select name=visitante>";
		$r=mysql_query("select * from equipos");
		
		while($equipo=mysql_fetch_array($r)){
			echo"<option value={$equipo['IDEquipo']}>{$equipo['Nombre']}</option>";
											}
		echo"</select>
	</div>
	
	<div class='6u 12u(mobile)'>
	<h5>Fecha</h5>
	<input type=text name=fecha placeholder='AAAA/MM/DD'>
	</div>
	
	<div class='6u 12u(mobile)'>
	<h5>Hora</h5>
	<input type=text name=hora placeholder='HH:MM:SS'>
	</div>
									
									<div class='12u$'>
										<input type='submit' value='Registrar Partido' />
									</div>
								</div>
							</form>

						</div>
					</section>

			</div>

		<!-- Footer -->
			<div id='footer'>

				<!-- Copyright -->
					<ul class='copyright'>
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href='http://html5up.net'>HTML5 UP</a></li>
					</ul>

			</div>

		<!-- Scripts -->
			<script src='assets/js/jquery.min.js'></script>
			<script src='assets/js/jquery.scrolly.min.js'></script>
			<script src='assets/js/jquery.scrollzer.min.js'></script>
			<script src='assets/js/skel.min.js'></script>
			<script src='assets/js/util.js'></script>
			<!--[if lte IE 8]><script src='assets/js/ie/respond.min.js'></script><![endif]-->
			<script src='assets/js/main.js'></script>

	</body>
</html>";

?>