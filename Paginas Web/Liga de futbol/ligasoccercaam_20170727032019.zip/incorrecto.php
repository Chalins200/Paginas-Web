<?php
session_start();

if ($_SESSION['ID']) {
	
}else{
header("Location:index.html");
}
?>
<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Liguilla de Futbol</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="shortcut icon" href="images/icono.png">
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
			<div id="header">

				<div class="top">

					<!-- Logo -->
						<div id="logo">
							<span class="image avatar48"><img src="images/avatar.png" alt="" /></span>
							<h1 id="title">Liguilla</h1>
							<p>Apertura 2016</p>
						</div>

					<!-- Nav -->
						<nav id="nav">
							<!--

								Prologue's nav expects links in one of two formats:

								1. Hash link (scrolls to a different section within the page)

								   <li><a href="#foobar" id="foobar-link" class="icon fa-whatever-icon-you-want skel-layers-ignoreHref"><span class="label">Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href="http://foobar.tld" id="foobar-link" class="icon fa-whatever-icon-you-want"><span class="label">Foobar</span></a></li>

							-->
							<ul>
								<li><a href="#two" id="top-link" class="skel-layers-ignoreHref"><span class="icon fa-home">Home</span></a></li>
								<li><a href="consultaJugadores.php" id="portfolio-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Registrar Jugadores</span></a></li>
								<li><a href="consultaJugadores.php" id="portfolio-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Consultar Jugadores</span></a></li>
								<li><a href="consultaEquipos.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-th">Registrar Equipos</span></a></li>
								<li><a href="consultaEquipos.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-th">Consultar Equipos</span></a></li>
								<li><a href="consultaRoles.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-th">Registrar Partidos</span></a></li>
								<li><a href="consultaRoles.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-th">Consulta Partidos</span></a></li>
								<li><a href="consultaResultados.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-th">Consultar Resultados</span></a></li>
								<li><a href="consultaAlbitros.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Registrar Arbitros</span></a></li>
								<li><a href="consultaAlbitros.php" id="about-link" class="skel-layers-ignoreHref"><span class="icon fa-user">Consultar Arbitros</span></a></li>
							<form action="login.php" method=POST enctype='multipart/form-data'>
								<div class="row">
									<div>
									Iniciar Sesi�n
									<input class="login" type="text" name="id" placeholder="ID" /></div>
									<div>
									<input class="login" type="password" name="clave" placeholder="Contrase�a" /></div>
								
									<div>
										<input class="loginB" align="rigth" type="submit" value="Iniciar" />
									</div>
								</div>
							</form>



						</nav>

				</div>

			</div>

		<!-- Main -->
			<div id="main">

				<!-- Portfolio -->
					<section id="portfolio" class="two">
						<div class="container">

							<header>
								<h2>SE ENCONTRO UN ERROR EN EL REGISTRO. <br> VERIFICA TUS DATOS</h2>
							</header>
						
						</div>
					</section>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollzer.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>