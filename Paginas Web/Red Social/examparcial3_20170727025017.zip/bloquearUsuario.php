<?php
include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";

if($_SESSION['ID']){
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$sl="SELECT * FROM {$_SESSION['Nombre']}A WHERE Nombre='{$_POST['UserBloq']}'";
$a=mysql_query($sl,$c);

if(strcmp($_POST['bloq'],"Bloquear")== 0){
$estado = "Bloqueado";
}else{
$estado = "Desbloqueado";
}

$sql="UPDATE {$_SESSION['Nombre']}A SET Estado='".$estado."' WHERE Nombre='{$_POST['UserBloq']}'";
$r=mysql_query($sql,$c);
if($r){
echo "<font size=5 color=white><center>SE HA REALIZADO CON EXITO</center></font>";
echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>";
}else{
echo "Error";
}	

}else{
header("Location:login.php");
}

?>


