<?php

include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);


	$sql="select * from ".$_POST['amigo']."C WHERE Tipo='Publicacion'";
	$r=mysql_query($sql,$c);
	$rcount=mysql_num_rows($r);
	$rcount += 1;
		$sql="insert into ".$_POST['amigo']."C Values('$rcount','{$_POST['publicacion']}','{$_SESSION['Nombre']}','Publicacion')";
		$r2=mysql_query($sql,$c);
		if($r2){
		echo "<font size=4 color=white><center>Su publicaci�n se a realizado correctamente</center></font>";
		}
		
	
	echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>";
}else{
header("Location:login.php");
}
echo "</body>";

?>
