<?php 
include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4><font color=white oncontextmenu='return false'>";

$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$nom=$_REQUEST['Nombre'];
$foto=$_FILES['foto']['name'];
$ruta=$_FILES['foto']['tmp_name'];
$destino="images/".$foto;
copy($ruta,$destino);

$r=mysql_query("insert into Usuarios (Nombre,Correo,Edad,Sexo,Usuario,Clave,foto)
values('{$_POST['Nombre']}','{$_POST['Correo']}','{$_POST['Edad']}','{$_POST['Sexo']}','{$_POST['Usuario']}','{$_POST['Clave']}','".$destino."')",$c); 


if($r){
// sql to create table Amigos
$query = mysql_query("CREATE TABLE ".$_POST['Nombre']."A"." (
Nombre VARCHAR(45) NOT NULL, Estado VARCHAR(45) NULL)");
// sql to create table Solicitudes
$query = mysql_query("CREATE TABLE ".$_POST['Nombre']."C"." (
id_Com INT(11) NOT NULL,
Texto VARCHAR(450) NOT NULL,
Usuario VARCHAR(45) NOT NULL,
Tipo VARCHAR(45) NOT NULL)");
echo "<h2><center>SU REGISTRO FUE EXITOSO</center></h2>";

}else{
echo "Verifique los datos";
}

echo"<a href=login.php><center><h3>Iniciar Sesion</h3></a>";
echo "</font>"; 

echo"</body>";

?> 