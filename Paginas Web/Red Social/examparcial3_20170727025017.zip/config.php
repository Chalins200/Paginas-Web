<?php
$datos = array('0' => 'mysql.webcindario.com',
              '1' => 'examparcial3',
              '2' => 'nolovuelvohacer');
?>