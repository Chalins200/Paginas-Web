<?php
include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);
if(strcmp($_POST['a'],$_SESSION['Nombre']) == 0){
header("Location:muro.php");
}
	$sq="SELECT * FROM ".$_POST['a']."A WHERE Nombre='{$_SESSION['Nombre']}'";
	$res=mysql_query($sq,$c);
	if($res){
	$rres=mysql_fetch_array($res);
	if(strcmp($rres['Estado'],"Bloqueado")== 0){
		echo "<font size=5 color=white><center>El usuario {$_POST['a']} te a bloqueado.</center></font>";
		echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>";
	}else{ 

echo "<TABLE border=0 width=950 align=center>";

echo "<TR><th colspan=2>Perfil de un Amigo";

$sql="select * from Usuarios where Nombre='{$_POST['a']}'";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);
$nombre = $arr['Nombre'];

echo "<table border=0 width=500 align=center>";
if($arr['foto'] != 'images/'){
echo "<tr><th rowspan><img src=' ".$arr['foto']." ' width=80 heigth=80></th></tr>";
}else{
	if(strcmp($arr['Sexo'],"M")== 0){
	echo "<tr><th rowspan><a href='cambiarFoto.php'><IMG SRC='images/hombre.jpg' width=80 heigth=80 alt='Clic para cambiar tu foto'></a></th></tr>";
	}else{
	echo "<tr><th rowspan=2><a href='cambiarFoto.php'><IMG SRC='images/mujer.png' width=80 heigth=80 alt='Clic para cambiar tu foto'></a></th></tr>";
	}
}
echo "<tr><td width=100 align=right><font size=4 color=white>Nombre: </td><td width=155><font size=4 color=white>{$arr['Nombre']}</font></td>
<td width=100 align=right><font size=4 color=white>Correo: </td><td width=155><font size=4 color=white>{$arr['Correo']}</font></td></tr>
<tr><td width=100 align=right><font size=4 color=white>Edad: </td><td width=155><font size=4 color=white>{$arr['Edad']}</font></td>
<td width=100 align=right><font size=4 color=white>Sexo: </td><td width=155><font size=4 color=white>{$arr['Sexo']}</font></td></tr></table>";


echo "<HR width=100%></th></TR>";	
echo "<HR width=100%>";
echo "<TR><TD width=700 align=center>";
$sql="select * from {$_POST['minombre']}"."A where Usuario='{$_POST['a']}'";
$r=mysql_query($sql,$c);
if($arr=mysql_fetch_array($r) == NULL){
 echo"<form action=solicitudAmistad2.php method=POST><center><input type=submit value='A�adir a mi lista de amigos'></center>
 <input type='hidden' name='amigo' value='{$_POST['a']}'>
 <input type='hidden' name='solicitante' value='{$_POST['minombre']}'></form>";

}else{
echo"<font size=5 color=white><center>Ya eres amigo de {$_POST['a']} </center></font>";
}

echo"</TD></TR>";  

echo "<TH colspan=2><form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>
</TH> </TABLE>";

}
}else{
echo "<font size=5 color=white><center>NO SE HA ENCONTRADO NINGUN AMIGO CON ESE NOMBRE</center></font>";
echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>";
	
}
////////
}else{
header("Location:login.php");
}



echo "</body>";
?>