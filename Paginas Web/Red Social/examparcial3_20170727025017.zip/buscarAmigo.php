<?php
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
echo "<form action=solicitudAmistad.php method=POST>";
echo "<TABLE border=0 width=250 align=center>";
echo "<input type='hidden' name='minombre' value='{$_POST['MiNombre']}'>";	
echo "<Th colspan=2><font color=white><center><h2>Buscar Amigo</h2></center></font></Th>";	
echo "<TR><TD width=50 align=right><font color=white>Nombre:</font></TD><TD width=50 align=center><input type=text name=a></TD></TR>";
echo "<TR><TD width=50 align=right><br></TD><TD width=50 align=right><input type=submit value='Buscar'></form></TD></TR>
<TH colspan=2><form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form> </TH></TABLE>";
echo "<BR><BR><BR>";

}else{
header("Location:login.php");
}
echo "</body>";
?>