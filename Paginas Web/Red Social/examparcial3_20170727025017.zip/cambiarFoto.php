<?php
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
echo "<TABLE BGCOLOR=#4682B4 border=0 align=center>";
echo "<form action=cambiarFoto2.php method=POST enctype='multipart/form-data'>";

echo "<Tr><Td><font size=5 color=white>
<font color=white>Foto:</font></Td>
<td><input type='file' name=foto value='' id=foto><input type=submit value=Subir ></td></Tr>";	
echo "</form></TABLE>";

}else{
header("Location:login.php");
}
echo "</body>";

?>