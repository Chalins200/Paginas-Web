<?php
include("config.php");
session_start();
if($_SESSION['ID']){

echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'><font color=white>";
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$nom=$_REQUEST['Nombre'];
$foto=$_FILES['foto']['name'];
$ruta=$_FILES['foto']['tmp_name'];
$destino="images/".$foto;
copy($ruta,$destino);
$sl="SELECT * FROM Usuarios WHERE Usuario='{$_SESSION['Usuario']}' and Clave='{$_SESSION['Clave']}'";
$r=mysql_query($sl,$c);
$sql="UPDATE Usuarios SET foto='".$destino."' WHERE Usuario='{$_SESSION['Usuario']}' and Clave='{$_SESSION['Clave']}'";
$r=mysql_query($sql,$c);
if($r){
header("Location:muro.php");
}else{

}

echo "</font></body>";

}else{
header("Location:login.php");
}
?>