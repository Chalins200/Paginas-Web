<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);
$sql="select * from Usuarios where Usuario='{$_POST['Usuario']}' and Clave='{$_POST['Clave']}' FOR UPDATE";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);
$_SESSION['ID'] = $arr['id_usuario'];
$_SESSION['Nombre'] = $arr['Nombre'];
$_SESSION['Correo'] = $arr['Correo'];
$_SESSION['Edad'] = $arr['Edad'];
$_SESSION['Sexo'] = $arr['Sexo'];
$_SESSION['Usuario'] = $arr['Usuario'];
$_SESSION['Clave'] = $arr['Clave'];
$_SESSION['Foto'] = $arr['foto'];
header("Location:muro.php");


?>
