<?php
include("config.php");
session_start();
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$color = substr(md5(time()), 0, 6);

echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){

echo "<TABLE border=0 align=center>";
echo "<Th align=right colspan=3 BGCOLOR=#21618C><IMG SRC='images/logpo.png' ><HR width=100%></Th>";	
echo "<TR><th colspan=2 BGCOLOR=#2874A6><font size=5 color=white>Datos de mi perfil
</font>";

$nombre = $_SESSION['Nombre'];

echo "<table border=0 width=500 align=center>";
if($_SESSION['Foto'] != 'images/'){
echo "<tr><th rowspan><img src='".$_SESSION['Foto']."' width=80 heigth=80></th></tr>";
}else{
	if(strcmp($_SESSION['Sexo'],"M")== 0){
	echo "<tr><th rowspan><a href='cambiarFoto.php'><IMG SRC='images/hombre.jpg' width=80 heigth=80 alt='Clic para cambiar tu foto'></a></th></tr>";
	}else{
	echo "<tr><th rowspan=2><a href='cambiarFoto.php'><IMG SRC='images/mujer.png' width=80 heigth=80 alt='Clic para cambiar tu foto'></a></th></tr>";
	}
}
echo "<tr><td width=100 align=right><font size=4 color=white>Nombre: </td><td width=155><font size=4 color=white>{$_SESSION['Nombre']}</font></td>
<td width=100 align=right><font size=4 color=white>Correo: </td><td width=155><font size=4 color=white>{$_SESSION['Correo']}</font></td></tr>
<tr><td width=100 align=right><font size=4 color=white>Edad: </td><td width=155><font size=4 color=white>{$_SESSION['Edad']}</font></td>
<td width=100 align=right><font size=4 color=white>Sexo: </td><td width=155><font size=4 color=white>{$_SESSION['Sexo']}</font></td></tr></table>";


echo "<HR width=100%></th></TR>";	
echo "";
echo "<TR><TD width=700 align=left BGCOLOR=#2E86C1>
<form action=publicaciones.php method=POST>
<textarea name='publicacion' rows='3' cols='70'>
�Qu� est�s pensando?</textarea><br>
<input type='hidden' name='amigo' value=$nombre >
<input type=submit name=Comentar value='Publicar'></font></form>";

echo "<HR width=100%>";
echo "<table border=0 align=left>";
	echo "<font size=4 color=white>Mis Publicaciones</font>";
	echo "<form action=resComentario.php method=POST> ";
	$sql="select * from ".$nombre."C Where Tipo='Publicacion'";
	$m=mysql_query($sql,$c);
	$i=0;
	while($srr=mysql_fetch_array($m)){
	$i +=1;
	echo "<tr><td align=left BGCOLOR=#5499C7  ><font size=4 color=white><HR width=100%> {$srr['Usuario']}:<br>
   	<textarea name='publicacionn".$i."' rows='3' cols='80' readonly='readonly'> {$srr['Texto']}</textarea>";
   	$sqll="select * from ".$nombre."C Where id_Com='{$srr['id_Com']}' and Tipo='Respuesta'";
	$mm=mysql_query($sqll,$c);
	while($ssrr=mysql_fetch_array($mm)){
	$mensaje=$ssrr['Texto'];
   	echo "<br>� {$ssrr['Usuario']}: $mensaje 
   	<input type='hidden' name='amig".$i."' value={$srr['Usuario']}>
   	<input type='hidden' name='respuesta".$i."' value=$mensaje>";
   	} 
   	echo "<br><input type=submit name=btn value='Responder".$i."'><HR width=100%></font></td></tr>";
	}
echo "<input type='hidden' name='num' value=$i ></form></table>";

echo "<HR width=100%>";


echo "<table border=0 align=left>";
	
	echo "<form action=resComentario.php method=POST> ";
	$sql="select * from ".$nombre."A";
	$m=mysql_query($sql,$c);
	echo "<font size=4 color=white>Publicaciones de amigos</font>";
	$i=0;
	$amigoCom = array();
	while($srr=mysql_fetch_array($m)){
	$i += 1;
	$amigoCom = array($i => $srr['Nombre']);
	
	//Verificar Bloqueo
	$l="select * from ".$_SESSION['Nombre']."A WHERE Nombre='{$srr['Nombre']}'";
	$p=mysql_query($l,$c);
	$z=mysql_fetch_array($p);
	if(strcmp($z['Estado'],"Bloqueado")== 0){
	//No se muestran las publicaciones
	
	}else{
	//Verificar Bloqueo
	$l="select * from ".$srr['Nombre']."A WHERE Nombre='{$_SESSION['Nombre']}'";
	$p=mysql_query($l,$c);
	$z=mysql_fetch_array($p);
	if(strcmp($z['Estado'],"Bloqueado")== 0){
	//No se muestran las publicaciones
	}else{
	//Mostrar las publicaciones de amigos
	$sqll="select * from ".$srr['Nombre']."C Where Usuario='{$srr['Nombre']}' and Tipo='Publicacion'";
	$mm=mysql_query($sqll,$c);
	$ii=0;
	while($ssrr=mysql_fetch_array($mm)){
	$ii += 1;
   	echo "<tr><td align=left ><font size=4 color=white> <HR width=100%>
   	{$srr['Nombre']}:<br>
   	<input type='hidden' name='amig".$ii."' value=$amigoCom[$i]>
   	<textarea name='publicacionn".$ii."' rows='3' cols='80' readonly='readonly'> {$ssrr['Texto']}</textarea>" ;
 
   	$sqll="select * from {$srr['Nombre']}C Where id_Com='{$ssrr['id_Com']}' and Tipo='Respuesta'";
	$mm=mysql_query($sqll,$c);
	while($ssrr=mysql_fetch_array($mm)){
	$mensaje=$ssrr['Texto'];
   	echo "<br>� {$ssrr['Usuario']}: $mensaje" ;
   	}
   	
   	echo "<br><input type=submit name=btn value='Responder".$ii."'><HR width=100%></font></td></tr>
   	<input type='hidden' name='nombre1' value='$nombre'>";
  	
  	}
  	}
	}
	}	

echo "<input type='hidden' name='num' value=$ii ></form></table></TD>";  

echo "<TD valign=top><font size=4 color=white>
MIS AMIGOS";
	$datos = array();
	$i=0;
	$sql="select * from ".$nombre."A";
	$r2=mysql_query($sql,$c);
	echo "<form action=muroA.php method=POST><table border=0>";
	while($ar=mysql_fetch_array($r2)){
	$i += 1;
	$datos[] = $ar; 
	$sql="select * from Usuarios WHERE Nombre='{$ar['Nombre']}'";
	$r3=mysql_query($sql,$c);
	$ar1=mysql_fetch_array($r3);
   	echo "<tr><td><img src='{$ar1['foto']}' width=30 heigth=30></td>
   	<td><input type=submit style='background:#".$color."' name=a value='{$ar['Nombre']}'></td></tr>";
	}
	
	
echo 	"</table><input type='hidden' name='MiNombre' value='$nombre'></form>
<HR width=100%>
SOLICITUDES DE AMISTAD";
	$datos = array();
	$i=0;
	$sql="select * from Solicitudes WHERE NombreAmigo='$nombre' and Estado='Pendiente'";
	$r2=mysql_query($sql,$c);
	echo "<form action=aceptarA.php method=POST><table border=0>";
	while($ar=mysql_fetch_array($r2)){
	$i += 1;
	$datos[] = $ar; 
	$sql="select * from Usuarios WHERE Nombre='{$ar['Solicitante']}'";
	$r3=mysql_query($sql,$c);
	$ar1=mysql_fetch_array($r3);
   	echo "<tr><td><img src='{$ar1['foto']}' width=30 heigth=30></td>
   	<td><input type=submit style='background:#".$color."' name=Solicitante value='{$ar['Solicitante']}'></td></tr>";
	}
	
	
echo 	"</table><input type=hidden name=YO value='$nombre'></form>
<HR width=100%>
NUEVA SOLICITUD DE AMISTAD <BR>
<form action=buscarAmigo.php method=POST>
<input type='hidden' name='MiNombre' value='$nombre'>
<CENTER><input type=submit value='BUSCAR'></CENTER></form>


<HR width=100%>
USUARIOS BLOQUEADOS";
	$sql="select * from {$_SESSION['Nombre']}A WHERE Estado='Bloqueado'";
	$r2=mysql_query($sql,$c);
	echo "<table border=0>";
	while($ar=mysql_fetch_array($r2)){
	$sql="select * from Usuarios WHERE Nombre='{$ar['Nombre']}'";
	$r3=mysql_query($sql,$c);
	$ar1=mysql_fetch_array($r3);
   	echo "<tr><td><img src='{$ar1['foto']}' width=30 heigth=30></td>
   	<td>{$ar['Nombre']}</td></tr>";
	}
	
	
echo 	"</table></font></TD></TR>";

echo "<TR align=center><th colspan=2 BGCOLOR=#21618C><HR width=100%>
<form action=cerrarsesion.php method=POST><center><input style='background:#21618C ; color:white' type=submit value='CERRAR SESION'></center></form>
</th></TR></TABLE>";


}else{
header("Location:login.php");
}


echo "</body>";
?>