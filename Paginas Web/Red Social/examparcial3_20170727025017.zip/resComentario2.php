<?php
include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$sql="insert into ".$_POST['amigo']."C VALUES('{$_POST['id_pu']}','{$_POST['respuesta']}','{$_SESSION['Nombre']}','Respuesta')";
$r=mysql_query($sql,$c);
if($r){
echo "<font size=4 color=white><center>EL COMENTARIO SE A ENVIADO</center> </font>";
}else{
echo $_POST['amigo'];
echo $_POST['id_pu'];
echo $_POST['respuesta'];
echo $_SESSION['Nombre'];
}
echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'>";

}else{
header("Location:login.php");
}

echo"</body>";
?>