<?php
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
echo "<TABLE border=0 bordercolor=white width=600 align=center>";
	
echo "<TR><TD width=50 align=right><font color=white><center><h2> "; 
$i = 0;
while($i <= $_POST['num']){
	if(strcmp($_POST['btn'],"Responder".$i."")== 0){
	$amigo = $_POST["amig".$i.""];
	$id = $i;
	echo $_POST['amig'.$i].":";
	echo $_POST["publicacionn".$i.""];
	
	}
$i += 1;
}
echo"</h2></center><HR width=100%></font></TD></TR>";	
echo "<TR><TD width=50 align=left><form action=resComentario2.php method=POST>
<font size=3 color=white>{$_SESSION['Nombre']} :<br>";
echo "<textarea name='respuesta' rows='3' cols='80' >Escribe aqu� tu comentario... </textarea>
<input type='hidden' name='amigo' value=$amigo>
<input type='hidden' name='id_pu' value=$id>";

echo "</font><br><input type=submit name='btnn' value='Responder'>";

echo"</form></TD></TR></TABLE>";

echo "<form action=muro.php method=POST><center> $Usuario <input type=submit value='Regresar'>";
}else{
header("Location:login.php");
}


echo "</body>";
?>