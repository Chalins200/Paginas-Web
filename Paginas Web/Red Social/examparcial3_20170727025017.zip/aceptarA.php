<?php
include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false' >";
if($_SESSION['ID']){
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$sql="select * from Usuarios where Nombre='{$_POST['Solicitante']}'";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);
echo "<TABLE border=1 width=950 align=center>";

echo "<TR><th colspan=2>Perfil de un Amigo";

$nombre = $arr['Nombre'];

echo "<table border=0 width=500 align=center>";
if($arr['foto'] != 'images/'){
echo "<tr><th rowspan><img src=' ".$arr['foto']." ' width=80 heigth=80></th></tr>";
}else{
	if(strcmp($arr['Sexo'],"M")== 0){
	echo "<tr><th rowspan><a href='cambiarFoto.php'><IMG SRC='images/hombre.jpg' width=80 heigth=80 alt='Clic para cambiar tu foto'></a></th></tr>";
	}else{
	echo "<tr><th rowspan=2><a href='cambiarFoto.php'><IMG SRC='images/mujer.png' width=80 heigth=80 alt='Clic para cambiar tu foto'></a></th></tr>";
	}
}
echo "<tr><td width=100 align=right><font size=4 color=white>Nombre: </td><td width=155><font size=4 color=white>{$arr['Nombre']}</font></td>
<td width=100 align=right><font size=4 color=white>Correo: </td><td width=155><font size=4 color=white>{$arr['Correo']}</font></td></tr>
<tr><td width=100 align=right><font size=4 color=white>Edad: </td><td width=155><font size=4 color=white>{$arr['Edad']}</font></td>
<td width=100 align=right><font size=4 color=white>Sexo: </td><td width=155><font size=4 color=white>{$arr['Sexo']}</font></td></tr></table>";


echo "<HR width=100%></th></TR>";	
echo "<HR width=100%>";
echo "<TR><TH width=700 align=center><form action=aceptarA2.php method=POST>
<font size=5 color=white> �Deseas aceptar la solicitud de amistad de {$_POST['Solicitante']}?</font><br>
<input type=submit name=Si value='Si'>
<input type=submit name=No value='No'>

<input type='hidden' name='solicitante' value='{$_POST['Solicitante']}'>
<input type='hidden' name='Yo' value='{$_SESSION['Nombre']}'><HR width=100%>
</form></TH></TR>
<TR><TH><form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form> </TH></TR></TABLE>";


}else{
header("Location:login.php");
}


echo "</body>";
?>