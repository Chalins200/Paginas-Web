<?php
include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

$r=mysql_query("insert into Solicitudes (NombreAmigo,Solicitante,Estado)
values('{$_POST['amigo']}','{$_POST['solicitante']}','Pendiente')",$c); 
if($r){
echo "<h2><center><font size'2' color=white>USTED HIZO UNA SALICITUD DE AMISTADA {$_POST['amigo']}</font></center></h2>";
echo "<form action=muro.php method=POST><center> <input type=submit value='Regresar'>";
}else{
echo "<h2><center>NO SE PUEDO REALIZAR LA SALICITUD DE AMISTADA</center></h2>";
}

}else{
header("Location:login.php");
}


echo "</body>";
?>