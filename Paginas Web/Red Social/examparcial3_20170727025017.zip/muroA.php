<?php
include("config.php");
session_start();
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false' >";

$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);

if($_SESSION['ID']){


	$sq="SELECT * FROM ".$_POST['a']."A WHERE Nombre='{$_SESSION['Nombre']}'";
	$res=mysql_query($sq,$c);
	$rres=mysql_fetch_array($res);
	if(strcmp($rres['Estado'],"Bloqueado")== 0){
		echo "<font size=5 color=white><center>El usuario {$_POST['a']} te a bloqueado.</center></font>";
		echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>";
	}else{ 
	
echo "<TABLE border=0 align=center>";
echo "<Th align=right colspan=3 BGCOLOR=#21618C><IMG SRC='images/logpo.png' ><HR width=100%></Th>";
echo "<TR><th colspan=2 BGCOLOR=#2874A6><font size=4 color=white>Perfil de un Amigo</font>
<form action=bloquearUsuario.php method=POST><center>";

$sq="SELECT * FROM {$_SESSION['Nombre']}A WHERE Nombre='{$_POST['a']}'";
$re=mysql_query($sq,$c);
$rrs=mysql_fetch_array($re);
if(strcmp($rrs['Estado'],"Bloqueado")== 0){
echo "<input align=right style='background:#21618C ; color:white' type=submit name=bloq value='Desbloquear'>";
}else{
echo "<input align=right style='background:#21618C ; color:white' type=submit name=bloq value='Bloquear'>";
}

$color = substr(md5(time()), 0, 6);
$sql="select * from Usuarios where Nombre='{$_POST['a']}'";
$r=mysql_query($sql,$c);
$arr=mysql_fetch_array($r);
$nombre = $arr['Nombre'];

echo "<input type='hidden' name='UserBloq' value=$nombre ></form>";
echo "<table border=0 align=center>";
if($arr['foto'] != NULL){
echo "<tr><th rowspan><img src=' ".$arr['foto']." ' width=100 heigth=100></th></tr>";
}else{
	if(strcmp($arr['Sexo'],"M")== 0){
	echo "<tr><th rowspan><IMG SRC='images/hombre.jpg'></th></tr>";
	}else{
	echo "<tr><th rowspan=2><IMG SRC='images/mujer.png'></th></tr>";
	}
}


echo "<tr><td width=100 align=right><font size=4 color=white>Nombre: </td><td width=155><font size=4 color=white>{$arr['Nombre']}</font></td>
<td width=100 align=right><font size=4 color=white>Correo: </td><td width=155><font size=4 color=white>{$arr['Correo']}</font></td></tr>
<tr><td width=100 align=right><font size=4 color=white>Edad: </td><td width=155><font size=4 color=white>{$arr['Edad']}</font></td>
<td width=100 align=right><font size=4 color=white>Sexo: </td><td width=155><font size=4 color=white>{$arr['Sexo']}</font></td></tr></table>";


echo "<HR width=100%></th></TR>";	
echo "<TR><TD width=700 align=left BGCOLOR=#2E86C1>
<form action=publicaciones.php method=POST>
<textarea name='publicacion' rows='3' cols='70'>
Escribe algo a tu amigo...</textarea><br>
<input type='hidden' name='amigo' value=$nombre >
<input type=submit name=Comentar value='Publicar'></font></form>";

echo "<HR width=100%>";
echo "<table border=0 align=left>";
echo "<font size=4 color=white><center>Publicaciones de {$_POST['a']}</center></font>";
	$sql="select * from {$_POST['a']}C Where Tipo='Publicacion'";
	$r=mysql_query($sql,$c);
	$i=0;
	echo "<form action=resComentario.php method=POST>";
	while($arr=mysql_fetch_array($r)){
	$i += 1;
   	echo "<tr><td align=left BGCOLOR=#$color><font size=4 color=white>
   	<input type='hidden' name='amig".$i."' value={$arr['Usuario']}>
   	{$arr['Usuario']}<br>
   	<textarea name='publicacionn".$i."' rows='3' cols='60' readonly='readonly'>{$arr['Texto']}</textarea>
   	</font><input type=submit name=btn value='Responder".$i."'></td></tr>";
   	
   	$sql="select * from {$_POST['a']}C Where id_Com='".$i."' and Tipo='Respuesta'";
	$rr=mysql_query($sql,$c);
	
	while($aarr=mysql_fetch_array($rr)){
   	echo "<tr><td align=left><font size=4 color=white>
   	<textarea name='respuesta".$i."' rows='3' cols='40' readonly='readonly'>{$aarr['Usuario']} : {$aarr['Texto']}</textarea>
   	</font></td></tr>";

	}
	}

echo "<input type='hidden' name='num' value=$i ></form></table></TD>";  

echo "<TD width=250 valign=top><font size=4 color=white>
AMIGOS
<ol>
	<ul type=square>";
	$datos = array();
	$i=0;
	$sql="select * from ".$nombre."A";
	$r2=mysql_query($sql,$c);
	echo "<form action=solicitudAmistad.php method=POST>";
	while($ar=mysql_fetch_array($r2)){
	$i += 1;
	$datos[] = $ar; 
   	echo "<li><input type=submit style='background:#".$color."' name=a value='{$ar['Nombre']}'></li>";
	}
	
	
echo 	"<input type='hidden' name='minombre' value='{$_POST['MiNombre']}'></form></ul>
</ol></font></TD></TR><TH colspan=2 BGCOLOR=#21618C><HR width=100%><form action=muro.php method=POST><center><input style='background:#21618C ; color:white' type=submit value='Regresar'></center></form></TH> </TABLE>";


}
//////
}else{
header("Location:login.php");
}



echo "</body>";
?>