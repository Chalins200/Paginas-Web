<?php
session_start();
include("config.php");
echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
if($_SESSION['ID']){
$c= mysql_connect($datos[0],$datos[1],$datos[2]);
mysql_select_db($datos[1],$c);


if(strcmp($_POST['Si'],"Si")== 0){
$sql="select * from Solicitudes where Solicitante='{$_POST['solicitante']}' and NombreAmigo='{$_POST['Yo']}'";
$r=mysql_query($sql,$c);

	if($r != NULL){
	$sql="UPDATE Solicitudes SET Estado='Aceptado' WHERE Solicitante='{$_POST['solicitante']}' and NombreAmigo='{$_POST['Yo']}'";
	$r=mysql_query($sql,$c);
	$sql="INSERT INTO {$_POST['Yo']}"."A (Nombre) values('{$_POST['solicitante']}')";
	$r=mysql_query($sql,$c);
	$sql="INSERT INTO {$_POST['solicitante']}"."A (Nombre) values('{$_POST['Yo']}')";
	$r=mysql_query($sql,$c);
	echo "<h3><font size=5 color=white><center>USTEDE AHORA ES AMIGO DE {$_POST['solicitante']}</center></font><h3>" ;
	echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>";
	}else{
	echo "<h3>Necesitas Iniciar Sesi�n<h3>" ;
	echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=login.php'><body BGCOLOR=#4682B4>Te vamos a redireccionar... </body></html>";
	}


}else{
	$sql="select * from Solicitudes where Solicitante='{$_POST['solicitante']}' and NombreAmigo='{$_POST['Yo']}'";
	$r=mysql_query($sql,$c);

	if($r != NULL){
	$sql="UPDATE Solicitudes SET Estado='Rechazado' WHERE Solicitante='{$_POST['solicitante']}' and NombreAmigo='{$_POST['Yo']}'";
	$r=mysql_query($sql,$c);
	echo "<h3><font size=5 color=white><center>USTEDE HA RECHAZADO A {$_POST['solicitante']}</center></font><h3>" ;
	echo "<form action=muro.php method=POST><center><input type=submit value='Regresar'></center></form>";
	}else{
	echo "<h3>Necesitas Iniciar Sesi�n<h3>" ;
	echo "<html><head></head><meta HTTP-EQUIV='Refresh' CONTENT='1; URL=login.php'><body BGCOLOR=#4682B4>Te vamos a redireccionar... </body></html>";
	}
}


}else{
header("Location:login.php");
}
echo "</body>";
?>