<?php

echo "<body BGCOLOR=#4682B4 oncontextmenu='return false'>";
echo "<TABLE BGCOLOR=#4682B4 width=1050 height=500 border=0 align=center>";
echo "<form action=login2.php method=POST>";
echo "<Th align=right colspan=3 BGCOLOR=#21618C><font size=7 color=white>Red Social</font> <IMG SRC='images/logpo.png' align=right><HR width=100%></Th>";
echo "<TR><TD align=left colspan=2><font color=white><font size=5 color=white align=center><strong>INICIO DE SESI�N</strong><BR></font>
Nombre de usuario:<br></font><input type=text name=Usuario></TD><TD rowspan=12  style='background: #FFF url(images/imagen.jpg) no-repeat center top'></TD></TR>";
echo "<TR><TD align=left colspan=2><font color=white>Contrase�a:<br></font><input type=password name=Clave></TD></TR>";
echo "<TR><TD align=left colspan=2><input type=submit value='Iniciar Sesion' style='width:100px; height:20px'></TD></TR></form>";
echo "<BR><BR><BR>";

echo "<form action=registrarUsuario2.php method=POST enctype='multipart/form-data'>";

echo "<Th align=left colspan=2><font size=5 color=white><HR width=100%> REGISTRATE</font><br>
<font color=white>Foto:</font><br><input type='file' name=foto value='' id=foto style='width:230px; height:25px'></Th>";	


echo "<TR><TD width=50 align=left><font color=white>Nombre:</font></TD>
<TD width=50 align=center><input type=text name=Nombre value=Juanito style='width:150px; height:25px'></TD></TR>";

echo "<TR><TD width=50 ><font color=white>Correo:</font></TD>
<TD width=50 align=center><input type=text name=Correo value=juanitoFlow@gmail.com style='width:150px; height:25px'></TD></TR>";

echo "<TR><TD width=50 ><font color=white>Edad:</font></TD>
<TD width=50 align=center><input type=text name=Edad value=18 style='width:150px; height:25px'></TD></TR>";

echo "<TR><TD width=50 ><font color=white>Sexo(M/F):</font></TD>
<TD width=50 align=center><input type=text name=Sexo value=M style='width:150px; height:25px'></TD></TR>";

echo "<TR><TD width=50 ><font color=white>Usuario:</font></TD>
<TD width=50 align=center><input type=text name=Usuario value=juancho style='width:150px; height:25px'></TD></TR>";

echo "<TR><TD width=50 ><font color=white>Contrase�a:</font></TD>
<TD width=50 align=center><input type=password name=Clave value=juanitoforever style='width:150px; height:25px'></TD></TR>";

echo "<tr><TH colspan=2><br><center><input type=submit value=Registrar style='width:100px; height:25px'></center></TH></tr>
<Th rowspan=8 colspan=2 ><br>� 2016 CAAM, Ing. Todos los derechos reservados</Th>
</form></TABLE>";
echo "</body>";
?>